/***
 *  This file defines the Sensor library version number 
 *  Normally, contributors should not modify this directly
 *  as it is managed by the MySensors Bot.
 */
#ifndef Version_h
#define Version_h

#define LIBRARY_VERSION "1.5.4"

#endif
