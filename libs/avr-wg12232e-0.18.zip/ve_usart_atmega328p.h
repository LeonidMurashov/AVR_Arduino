/*
 * usart_atmega328p.h
 *
 *  Created on: 01.11.2012
 *      Author: andrey
 */

#ifndef USART_ATMEGA328P_H_
#define USART_ATMEGA328P_H_

inline bool _Usart::isSynchronousMode() const
{
	return (REG_(ucsrc).umsel == 1);
}
inline void _Usart::setSynchronousMode()
{
	REG_(ucsrc).umsel = 1;
}
inline void _Usart::setAsynchronousMode()
{
	REG_(ucsrc).umsel = 0;
}
inline bool _Usart::isMasterSPIMode() const
{
	return (REG_(ucsrc).umsel == 3);
}
inline void _Usart::setMasterSPIMode()
{
	REG_(ucsrc).umsel = 3;
}
inline _Usart::Parity _Usart::parityMode() const
{
	return (Parity) REG_(ucsrc).upm;
}
inline void _Usart::setParityMode(Parity val)
{
	REG_(ucsrc).upm = val;
}
inline _Usart::StopBit _Usart::stopbitMode() const
{
	return (StopBit) REG_(ucsrc).usbs;
}
inline void _Usart::setStopbitMode(StopBit val)
{
	REG_(ucsrc).usbs = val;
}
inline uint8_t _Usart::charSize() const
{
	return REG_(ucsrc).ucsz;
}
inline void _Usart::setCharSize(uint8_t val)
{
	REG_(ucsrc).ucsz = val;
}
inline _Usart::ClockPolarity _Usart::clockPolarity() const
{
	return (ClockPolarity) REG_(ucsrc).ucpol;
}
inline void _Usart::setClockPolarity(ClockPolarity val)
{
	REG_(ucsrc).ucpol = val;
}
inline long _Usart::baudRate() const
{
	unsigned char _div = isSynchronousMode() ? 2 : isDoubleSpeed() ? 8 : 16;
	unsigned long ret = F_CPU / _div;
	ret /= REG_(ubrr) + 1;
	return ret;
}
inline void _Usart::setBaudRate(long val)
{
	unsigned char _div = isSynchronousMode() ? 2 : isDoubleSpeed() ? 8 : 16;
	unsigned long _ubrr = F_CPU / _div;
	_ubrr /= val;
	REG(ubrr) = --_ubrr;
}


#endif /* USART_ATMEGA328P_H_ */
