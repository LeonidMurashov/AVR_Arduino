/*
 * usbdevep.h
 *
 *  Created on: 09.12.2012
 *      Author: andrey
 */

#ifndef USBDEVEP_H_
#define USBDEVEP_H_

/**
 *  USB Device Endpoint class.
 */
class UsbEndpoint : public AVR_USBEP
{
public:
	typedef enum {
		Control     = 0,
		Isochronous = 1,
		Bulk        = 2,
		Interrupt   = 3
	} Type;
	typedef enum {
		OUT = 0,
		IN = 1
	} Dir;
	typedef enum {
		Size_8bytes   = 0,
		Size_16bytes  = 1,
		Size_32bytes  = 2,
		Size_64bytes  = 3,
		Size_128bytes = 4,
		Size_256bytes = 5,
		Size_512bytes = 6
	} Size;
	typedef enum {
		Single = 0,
		Double = 1
	} Bank;
	typedef enum {
		Data0 = 0,
		Data1 = 1
	} PID;
	typedef enum {
		AllFree     = 0,
		Busy_1bank  = 1,
		Busy_2banks = 2
	} BusyBanks;
	typedef enum {
		Bank0 = 0,
		Bank1 = 1
	} CurrBank;
public:
	unsigned char number() const;
	void setNumber(unsigned char val);
	void resetEndpointFIFO(unsigned char ep);
	void requestSTALL();
	bool isSETUPReceived() const;
	void disableSTALLHandshake();
	void resetDataToggle();
	bool isEnabled() const;
	void enable();
	void disable();
	Type type() const;
	void setType(Type val);
	Dir direction() const;
	void setDirection(Dir val);
	Size size() const;
	void setSize(Size val);
	Bank bank() const;
	void setBank(Bank val);
	bool isMemoryAllocated() const;
	void allocateMemory();
	void freeMemory();
	bool isConfigurationOK() const;
	bool isOverflowErrorInt() const;
	void clearOverflowErrorInt();
	bool isUnderflowErrorInt() const;
	void clearUnderflowErrorInt();
	PID pid() const;
	BusyBanks busyBanks() const;
	Dir controlDirection() const;
	CurrBank currentBank() const;
	bool isFIFOControlInt() const;
	void clearFIFOControlInt();
	bool isNAKINReceivedInt() const;
	void clearNAKINReceivedInt();
	bool isReadWriteAllowed() const;
	bool isNAKOUTReceivedInt() const;
	void clearNAKOUTReceivedInt();
	bool isSETUPReceivedInt() const;
	void clearSETUPReceivedInt();
	bool isOUTDataReceivedInt() const;
	void clearOUTDataReceivedInt();
	void killLastWrittenBank();
	bool isStalledInt() const;
	void clearStalledInt();
	bool isTransmitterReadyInt() const;
	void clearTransmitterReadyInt();
	bool isFlowErrorIntEnabled() const;
	void enableFlowErrorInt();
	void disableFlowErrorInt();
	bool isNAKINReceivedIntEnabled() const;
	void enableNAKINReceivedInt();
	void disableNAKINReceivedInt();
	bool isNAKOUTReceivedIntEnabled() const;
	void enableNAKOUTReceivedInt();
	void disableNAKOUTReceivedInt();
	bool isSETUPReceivedIntEnabled() const;
	void enableSETUPReceivedInt();
	void disableSETUPReceivedInt();
	bool isOUTDataReceivedIntEnabled() const;
	void enableOUTDataReceivedInt();
	void disableOUTDataReceivedInt();
	bool isStalledIntEnabled() const;
	void enableStalledInt();
	void disableStalledInt();
	bool isTransmitterReadyIntEnabled() const;
	void enableTransmitterReadyInt();
	void disableTransmitterReadyInt();
	UsbEndpoint& operator >> (unsigned char &uch);
	UsbEndpoint& operator >> (char &uch);
	UsbEndpoint& operator << (unsigned char uch);
	UsbEndpoint& operator << (char uch);
	unsigned int byteCount() const;
	bool isInt(unsigned char ep) const;
};

inline unsigned char UsbEndpoint::number() const
{
	return REG(uenum);
}
inline void UsbEndpoint::setNumber(unsigned char val)
{
	REG(uenum) = val & 7;
}
inline void UsbEndpoint::resetEndpointFIFO(unsigned char ep)
{
	REG(uenum) |= _BV(ep);
	REG(uenum) &= ~_BV(ep);
}
inline void UsbEndpoint::requestSTALL()
{
	REG_(ueconx).stallrq = true;
}
inline bool UsbEndpoint::isSETUPReceived() const
{
	return ! REG_(ueconx).stallrq;
}
inline void UsbEndpoint::disableSTALLHandshake()
{
	REG_(ueconx).stallrqc = true;
}
inline void UsbEndpoint::resetDataToggle()
{
	REG_(ueconx).rstdt = true;
}
inline bool UsbEndpoint::isEnabled() const
{
	return REG_(ueconx).epen;
}
inline void UsbEndpoint::enable()
{
	REG_(ueconx).epen = true;
}
inline void UsbEndpoint::disable()
{
	REG_(ueconx).epen = false;
}
inline UsbEndpoint::Type UsbEndpoint::type() const
{
	return (Type) REG_(uecfg0x).eptype;
}
inline void UsbEndpoint::setType(Type val)
{
	REG_(uecfg0x).eptype = val;
}
inline UsbEndpoint::Dir UsbEndpoint::direction() const
{
	return (Dir) REG_(uecfg0x).epdir;
}
inline void UsbEndpoint::setDirection(Dir val)
{
	REG_(uecfg0x).epdir = val;
}
inline UsbEndpoint::Size UsbEndpoint::size() const
{
	return (Size) REG_(uecfg1x).epsize;
}
inline void UsbEndpoint::setSize(Size val)
{
	REG_(uecfg1x).epsize = val;
}
inline UsbEndpoint::Bank UsbEndpoint::bank() const
{
	return (Bank) REG_(uecfg1x).epbk;
}
inline void UsbEndpoint::setBank(Bank val)
{
	REG_(uecfg1x).epbk = val;
}
inline bool UsbEndpoint::isMemoryAllocated() const
{
	return REG_(uecfg1x).alloc;
}
inline void UsbEndpoint::allocateMemory()
{
	REG_(uecfg1x).alloc = true;
}
inline void UsbEndpoint::freeMemory()
{
	REG_(uecfg1x).alloc = false;
}
inline bool UsbEndpoint::isConfigurationOK() const
{
	return REG_(uesta0x).cfgok;
}
inline bool UsbEndpoint::isOverflowErrorInt() const
{
	return REG_(uesta0x).overfi;
}
inline void UsbEndpoint::clearOverflowErrorInt()
{
	REG_(uesta0x).overfi = false;
}
inline bool UsbEndpoint::isUnderflowErrorInt() const
{
	return REG_(uesta0x).underfi;
}
inline void UsbEndpoint::clearUnderflowErrorInt()
{
	REG_(uesta0x).underfi = false;
}
inline UsbEndpoint::PID UsbEndpoint::pid() const
{
	return (PID) REG_(uesta0x).dtseq;
}
inline UsbEndpoint::BusyBanks UsbEndpoint::busyBanks() const
{
	return (BusyBanks) REG_(uesta0x).nbusybk;
}
inline UsbEndpoint::Dir UsbEndpoint::controlDirection() const
{
	return (Dir) REG_(uesta1x).ctrldir;
}
inline UsbEndpoint::CurrBank UsbEndpoint::currentBank() const
{
	return (CurrBank) REG_(uesta1x).currbk;
}
inline bool UsbEndpoint::isFIFOControlInt() const
{
	return REG_(ueintx).fifocon;
}
inline void UsbEndpoint::clearFIFOControlInt()
{
	REG_(ueintx).fifocon = false;
}
inline bool UsbEndpoint::isNAKINReceivedInt() const
{
	return REG_(ueintx).nakini;
}
inline void UsbEndpoint::clearNAKINReceivedInt()
{
	REG_(ueintx).nakini = false;
}
inline bool UsbEndpoint::isReadWriteAllowed() const
{
	return REG_(ueintx).rwal;
}
inline bool UsbEndpoint::isNAKOUTReceivedInt() const
{
	return REG_(ueintx).nakouti;
}
inline void UsbEndpoint::clearNAKOUTReceivedInt()
{
	REG_(ueintx).nakouti = false;
}
inline bool UsbEndpoint::isSETUPReceivedInt() const
{
	return REG_(ueintx).rxstpi;
}
inline void UsbEndpoint::clearSETUPReceivedInt()
{
	REG_(ueintx).rxstpi = false;
}
inline bool UsbEndpoint::isOUTDataReceivedInt() const
{
	return REG_(ueintx).rxouti;
}
inline void UsbEndpoint::clearOUTDataReceivedInt()
{
	REG_(ueintx).rxouti = false;
}
inline void UsbEndpoint::killLastWrittenBank()
{
	REG_(ueintx).rxouti = false;
}
inline bool UsbEndpoint::isStalledInt() const
{
	return REG_(ueintx).stalledi;
}
inline void UsbEndpoint::clearStalledInt()
{
	REG_(ueintx).stalledi = false;
}
inline bool UsbEndpoint::isTransmitterReadyInt() const
{
	return REG_(ueintx).txini;
}
inline void UsbEndpoint::clearTransmitterReadyInt()
{
	REG_(ueintx).txini = false;
}
inline bool UsbEndpoint::isFlowErrorIntEnabled() const
{
	return REG_(ueienx).flerre;
}
inline void UsbEndpoint::enableFlowErrorInt()
{
	REG_(ueienx).flerre = true;
}
inline void UsbEndpoint::disableFlowErrorInt()
{
	REG_(ueienx).flerre = false;
}
inline bool UsbEndpoint::isNAKINReceivedIntEnabled() const
{
	return REG_(ueienx).nakine;
}
inline void UsbEndpoint::enableNAKINReceivedInt()
{
	REG_(ueienx).nakine = true;
}
inline void UsbEndpoint::disableNAKINReceivedInt()
{
	REG_(ueienx).nakine = false;
}
inline bool UsbEndpoint::isNAKOUTReceivedIntEnabled() const
{
	return REG_(ueienx).nakoute;
}
inline void UsbEndpoint::enableNAKOUTReceivedInt()
{
	REG_(ueienx).nakoute = true;
}
inline void UsbEndpoint::disableNAKOUTReceivedInt()
{
	REG_(ueienx).nakoute = false;
}
inline bool UsbEndpoint::isSETUPReceivedIntEnabled() const
{
	return REG_(ueienx).rxstpe;
}
inline void UsbEndpoint::enableSETUPReceivedInt()
{
	REG_(ueienx).rxstpe = true;
}
inline void UsbEndpoint::disableSETUPReceivedInt()
{
	REG_(ueienx).rxstpe = false;
}
inline bool UsbEndpoint::isOUTDataReceivedIntEnabled() const
{
	return REG_(ueienx).rxoute;
}
inline void UsbEndpoint::enableOUTDataReceivedInt()
{
	REG_(ueienx).rxoute = true;
}
inline void UsbEndpoint::disableOUTDataReceivedInt()
{
	REG_(ueienx).rxoute = false;
}
inline bool UsbEndpoint::isStalledIntEnabled() const
{
	return REG_(ueienx).stallede;
}
inline void UsbEndpoint::enableStalledInt()
{
	REG_(ueienx).stallede = true;
}
inline void UsbEndpoint::disableStalledInt()
{
	REG_(ueienx).stallede = false;
}
inline bool UsbEndpoint::isTransmitterReadyIntEnabled() const
{
	return REG_(ueienx).txine;
}
inline void UsbEndpoint::enableTransmitterReadyInt()
{
	REG_(ueienx).txine = true;
}
inline void UsbEndpoint::disableTransmitterReadyInt()
{
	REG_(ueienx).txine = false;
}
inline UsbEndpoint& UsbEndpoint::operator >> (unsigned char &uch)
{
	uch = REG(uedatx);
	return (*this);
}
inline UsbEndpoint& UsbEndpoint::operator >> (char &uch)
{
	uch = REG(uedatx);
	return (*this);
}
inline UsbEndpoint& UsbEndpoint::operator << (unsigned char uch)
{
	REG(uedatx) = uch;
	return (*this);
}
inline UsbEndpoint& UsbEndpoint::operator << (char uch)
{
	REG(uedatx) = uch;
	return (*this);
}
inline unsigned int UsbEndpoint::byteCount() const
{
	return REGW(uebcx);
}
inline bool UsbEndpoint::isInt(unsigned char ep) const
{
	return REG(ueint) & _BV(ep);
}

#endif /* USBDEVEP_H_ */
