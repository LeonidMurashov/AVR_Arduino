/*
 * sleepmodecontrol.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef SLEEPMODECONTROL_H_
#define SLEEPMODECONTROL_H_

/**
 *  Sleep Mode Control class.
 */
class SleepControl: public AVR_SLEEP
{
public:
	typedef enum {
		IDLE = 0,
		ADC_NR = 1,
		PWR_DOWN = 2,
		PWR_SAVE = 3,
		STANDBY = 6,
		EXT_STANDBY = 7
	} Mode;
public:
	Mode mode() const;
	void setMode(Mode val);
	bool isSleepEnabled() const;
	void enableSleep();
	void disableSleep();
};

inline SleepControl::Mode SleepControl::mode() const
{
	return (Mode) REG_(smcr).sm;
}
inline void SleepControl::setMode(Mode val)
{
	REG_(smcr).sm = val;
}
inline bool SleepControl::isSleepEnabled() const
{
	return REG_(smcr).se;
}
inline void SleepControl::enableSleep()
{
	REG_(smcr).se = true;
}
inline void SleepControl::disableSleep()
{
	REG_(smcr).se = false;
}
inline void sleep()
{
	__asm__ __volatile__("sleep");
}

#endif /* SLEEPMODECONTROL_H_ */
