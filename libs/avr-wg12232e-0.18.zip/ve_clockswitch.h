/*
 * clockswitch.h
 *
 *  Created on: 07.12.2012
 *      Author: andrey
 */

#ifndef CLOCKSWITCH_H_
#define CLOCKSWITCH_H_

/**
 *  Clock Switch class.
 */
class ClockSwitch : public AVR_CLKSEL
{
public:
	typedef enum {
		BOD_enabled     = 0,
		FastRisingPower = 1,
		SlowRisingPower = 2
	} StartupTime;
	typedef enum {
		RC  = 0,
		Ext = 1
	} CPUClock;
	typedef enum {
		External     = 0,
		InternalRC   = 2,
		LowFreq_1CK  = 4,
		LowFreq_32CK = 5,
		LowPower_400kHz_Ceramic = 8,
		LowPower_400kHz_Crystal = 9,
		LowPower_900kHz_Ceramic = 10,
		LowPower_900kHz_Crystal = 11,
		LowPower_3MHz_Ceramic   = 12,
		LowPower_3MHz_Crystal   = 13,
		LowPower_8MHz_Ceramic   = 14,
		LowPower_8MHz_Crystal   = 15
	} ClockOptions;
public:
	StartupTime rcStartupTime() const;
	void setRCStartupTime(StartupTime val);
	StartupTime extStartupTime() const;
	void setExtStartupTime(StartupTime val);
	bool isRCEnabled() const;
	void enableRC();
	void disableRC();
	bool isExtEnabled() const;
	void enableExt();
	void disableExt();
	CPUClock cpuClock() const;
	void setCPUClock(CPUClock val);
	ClockOptions rcOptions() const;
	void setRCOptions(ClockOptions val);
	ClockOptions extOptions() const;
	void setExtOptions(ClockOptions val);
	bool isRCOn() const;
	bool isExtOn() const;
};

inline ClockSwitch::StartupTime ClockSwitch::rcStartupTime() const
{
	return (StartupTime) REG_(clksel0).rcsut;
}
inline void ClockSwitch::setRCStartupTime(StartupTime val)
{
	REG_(clksel0).rcsut = val;
}
inline ClockSwitch::StartupTime ClockSwitch::extStartupTime() const
{
	return (StartupTime) REG_(clksel0).exsut;
}
inline void ClockSwitch::setExtStartupTime(StartupTime val)
{
	REG_(clksel0).exsut = val;
}
inline bool ClockSwitch::isRCEnabled() const
{
	return REG_(clksel0).rce;
}
inline void ClockSwitch::enableRC()
{
	REG_(clksel0).rce = true;
}
inline void ClockSwitch::disableRC()
{
	REG_(clksel0).rce = false;
}
inline bool ClockSwitch::isExtEnabled() const
{
	return REG_(clksel0).exte;
}
inline void ClockSwitch::enableExt()
{
	REG_(clksel0).exte = true;
}
inline void ClockSwitch::disableExt()
{
	REG_(clksel0).exte = false;
}
inline ClockSwitch::CPUClock ClockSwitch::cpuClock() const
{
	return (CPUClock) REG_(clksel0).clks;
}
inline void ClockSwitch::setCPUClock(CPUClock val)
{
	REG_(clksel0).clks = val;
}
inline ClockSwitch::ClockOptions ClockSwitch::rcOptions() const
{
	return (ClockOptions) REG_(clksel1).rccksel;
}
inline void ClockSwitch::setRCOptions(ClockOptions val)
{
	REG_(clksel1).rccksel = val;
}
inline ClockSwitch::ClockOptions ClockSwitch::extOptions() const
{
	return (ClockOptions) REG_(clksel1).excksel;
}
inline void ClockSwitch::setExtOptions(ClockOptions val)
{
	REG_(clksel1).excksel = val;
}
inline bool ClockSwitch::isRCOn() const
{
	return REG_(clksta).rcon;
}
inline bool ClockSwitch::isExtOn() const
{
	return REG_(clksta).exton;
}

#endif /* CLOCKSWITCH_H_ */
