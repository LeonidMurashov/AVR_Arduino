/*
 * usart.h
 *
 *  Created on: 21.01.2012
 *      Author: andrey
 */

#ifndef USART_H_
#define USART_H_

#if defined(VE_ATmega325) || \
    defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega32U4) || \
	defined(VE_ATmega644PA) || \
    defined(VE_ATmega1284P)

#define USART_PARITY_NONE       (0)
#define USART_PARITY_EVEN       (1)
#define USART_PARITY_ODD        (2)

#define USART_STOP_1BIT         (false)
#define USART_STOP_2BIT         (true)

#define USART_CKPOL_TXRISING    (false)
#define USART_CKPOL_TXFALLING   (true)

#endif

#if defined(VE_ATmega32)
#define USART_PARITY_NONE       (0)
#define USART_PARITY_EVEN       (_BV(UPM1))
#define USART_PARITY_ODD        (_BV(UPM1) | _BV(UPM0))
#define USART_PARITY_MASK       (_BV(UPM1) | _BV(UPM0))

#define USART_STOP_1BIT         (0)
#define USART_STOP_2BIT         (_BV(USBS))
#define USART_STOP_MASK         (_BV(USBS))

#define USART_CHARSIZE_MASK     (_BV(UCSZ1) | _BV(UCSZ0))

#define USART_CKPOL_TXRISING    (0)
#define USART_CKPOL_TXFALLING   (_BV(UCPOL))
#define USART_CKPOL_MASK        (_BV(UCPOL))
#endif

/**
 *  USART class.
 */
class _Usart: public AVR_USART
{
public:
    typedef enum
    {
        ParityNone = USART_PARITY_NONE,
        ParityEven = USART_PARITY_EVEN,
        ParityOdd = USART_PARITY_ODD
    } Parity;
    typedef enum
    {
        Stop1Bit = USART_STOP_1BIT, Stop2Bit = USART_STOP_2BIT
    } StopBit;
    typedef enum
    {
        TXRisingXCK = USART_CKPOL_TXRISING,
        TXFallingXCK = USART_CKPOL_TXFALLING
    } ClockPolarity;
public:
    bool isReceiveComplete() const;
    bool isTransmitComplete() const;
    void setTransmitComplete();
    bool isDataRegisterEmpty() const;
    bool isFrameError() const;
    bool isDataOverRun() const;
    bool isParityError() const;
    bool isDoubleSpeed() const;
    void setDoubleSpeed();
    void setSingleSpeed();
    bool isMultiProcComMode() const;
    void setMultiProcComModeOn();
    void setMultiProcComModeOff();
    bool isRxCompleteInterruptEnabled() const;
    void rxCompleteInterruptEnable();
    void rxCompleteInterruptDisable();
    bool isTxCompleteInterruptEnabled() const;
    void txCompleteInterruptEnable();
    void txCompleteInterruptDisable();
    bool isDataRegEmptyInterruptEnabled() const;
    void dataRegEmptyInterruptEnable();
    void dataRegEmptyInterruptDisable();
    bool isReceiverEnabled() const;
    void receiverEnable();
    void receiverDisable();
    bool isTransmitterEnabled() const;
    void transmitterEnable();
    void transmitterDisable();

    bool isSynchronousMode() const;
    void setSynchronousMode();
    void setAsynchronousMode();
    Parity parityMode() const;
    void setParityMode(Parity val);
    StopBit stopbitMode() const;
    void setStopbitMode(StopBit val);
    uint8_t charSize() const;
    void setCharSize(uint8_t val);
    ClockPolarity clockPolarity() const;
    void setClockPolarity(ClockPolarity val);
    long baudRate() const;
    void setBaudRate(long val);

    _Usart& operator >>(uint8_t& _data);
    _Usart& operator >>(char& _data);
    _Usart& operator <<(uint8_t _data);
    _Usart& operator <<(char _data);
    _Usart& operator <<(const char *_str);

#if defined(VE_ATmega32)
    uint8_t readUBRRH() const;
    uint8_t readUCSRC() const;
    void writeUBRRH(uint8_t val);
    void writeUCSRC(uint8_t val);
#endif
#if defined(VE_ATmega328P) || \
	defined(VE_ATmega32U4) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
    bool isMasterSPIMode() const;
    void setMasterSPIMode();
#endif
};

#if defined(VE_ATmega32)
#include "ve_usart_atmega32.h"
#endif
#if defined(VE_ATmega325)
#include "ve_usart_atmega325.h"
#endif
#if defined(VE_ATmega328P) || \
	defined(VE_ATmega32U4) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
#include "ve_usart_atmega328p.h"
#endif

inline bool _Usart::isReceiveComplete() const
{
    return REG_(ucsra).rxc;
}

inline bool _Usart::isTransmitComplete() const
{
    return REG_(ucsra).txc;
}

inline void _Usart::setTransmitComplete()
{
    REG_(ucsra).txc = true;
}

inline bool _Usart::isDataRegisterEmpty() const
{
    return REG_(ucsra).udre;
}

inline bool _Usart::isFrameError() const
{
    return REG_(ucsra).fe;
}

inline bool _Usart::isDataOverRun() const
{
    return REG_(ucsra).dor;
}

inline bool _Usart::isParityError() const
{
    return REG_(ucsra).upe;
}

inline bool _Usart::isDoubleSpeed() const
{
    return REG_(ucsra).u2x;
}

inline void _Usart::setDoubleSpeed()
{
    REG_(ucsra).u2x = true;
}

inline void _Usart::setSingleSpeed()
{
    REG_(ucsra).u2x = false;
}

inline bool _Usart::isMultiProcComMode() const
{
    return REG_(ucsra).mpcm;
}

inline void _Usart::setMultiProcComModeOn()
{
    REG_(ucsra).mpcm = true;
}

inline void _Usart::setMultiProcComModeOff()
{
    REG_(ucsra).mpcm = false;
}

inline bool _Usart::isRxCompleteInterruptEnabled() const
{
    return REG_(ucsrb).rxcie;
}

inline void _Usart::rxCompleteInterruptEnable()
{
    REG_(ucsrb).rxcie = true;
}

inline void _Usart::rxCompleteInterruptDisable()
{
    REG_(ucsrb).rxcie = false;
}

inline bool _Usart::isTxCompleteInterruptEnabled() const
{
    return REG_(ucsrb).txcie;
}

inline void _Usart::txCompleteInterruptEnable()
{
    REG_(ucsrb).txcie = true;
}

inline void _Usart::txCompleteInterruptDisable()
{
    REG_(ucsrb).txcie = false;
}

inline bool _Usart::isDataRegEmptyInterruptEnabled() const
{
    return REG_(ucsrb).udrie;
}

inline void _Usart::dataRegEmptyInterruptEnable()
{
    REG_(ucsrb).udrie = true;
}

inline void _Usart::dataRegEmptyInterruptDisable()
{
    REG_(ucsrb).udrie = false;
}

inline bool _Usart::isReceiverEnabled() const
{
    return REG_(ucsrb).rxen;
}

inline void _Usart::receiverEnable()
{
    REG_(ucsrb).rxen = true;
}

inline void _Usart::receiverDisable()
{
    REG_(ucsrb).rxen = false;
}

inline bool _Usart::isTransmitterEnabled() const
{
    return REG_(ucsrb).txen;
}

inline void _Usart::transmitterEnable()
{
    REG_(ucsrb).txen = true;
}

inline void _Usart::transmitterDisable()
{
    REG_(ucsrb).txen = false;
}

inline _Usart& _Usart::operator >>(uint8_t& _data)
{
	while (!isReceiveComplete());
    _data = REG(udr);
    return (*this);
}

inline _Usart& _Usart::operator >>(char& _data)
{
	while (!isReceiveComplete());
    _data = REG(udr);
    return (*this);
}

inline _Usart& _Usart::operator <<(uint8_t _data)
{
    while (!isDataRegisterEmpty());
    REG(udr) = _data;
    return (*this);
}

inline _Usart& _Usart::operator <<(char _data)
{
    while (!isDataRegisterEmpty());
    REG(udr) = _data;
    return (*this);
}

inline _Usart& _Usart::operator <<(const char *_str)
{
    const char *p = _str;
    while(*p) {
        (*this) << (*p);
        ++p;
    }
    return (*this);
}

#endif /* USART_H_ */
