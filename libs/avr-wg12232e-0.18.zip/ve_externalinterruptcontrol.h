/*
 * externalinterruptcontrol.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef EXTERNALINTERRUPTCONTROL_H_
#define EXTERNALINTERRUPTCONTROL_H_

#define EIC_DECLARE(num, regletter) \
	inline SenseType senseType##num() const { \
		return (SenseType) REG_(eicr##regletter).isc##num; \
	} \
	inline void setSenseType##num(SenseType val) { \
		REG_(eicr##regletter).isc##num = val; \
	}

/**
 *  External Interrupt Control class.
 */
class ExtIntControl : public AVR_EXTINTCTRL
{
public:
	typedef enum {
		LOW_LEVEL = 0,
		ANY_CHANGE,
		FALLING_EDGE,
		RISING_EDGE
	} SenseType;
public:
	EIC_DECLARE(0, a)

#if defined(VE_ATmega328P)
	EIC_DECLARE(1, a)
#endif

#if defined(VE_ATmega2560)
	EIC_DECLARE(1, a)
	EIC_DECLARE(2, a)
	EIC_DECLARE(3, a)
	EIC_DECLARE(4, b)
	EIC_DECLARE(5, b)
	EIC_DECLARE(6, b)
	EIC_DECLARE(7, b)
#endif

#if defined(VE_ATmega32)
	EIC_DECLARE(1, a)
	EIC_DECLARE(2, b)
#endif

#if defined(VE_ATmega32U4)
	EIC_DECLARE(1, a)
	EIC_DECLARE(2, a)
	EIC_DECLARE(3, a)
	EIC_DECLARE(6, b)
#endif

#if defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
	EIC_DECLARE(1, a)
	EIC_DECLARE(2, a)
#endif

};

#endif /* EXTERNALINTERRUPTCONTROL_H_ */
