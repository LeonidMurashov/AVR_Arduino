
VEduino Library for Arduino and Arduino MEGA compatible boards.

This library is in development state.

Microcontrollers that are supported:

 * ATmega48P/88P/168P/328P
 * ATmega640/1280/1281/2560/2561
 * ATmega16U4/32U4
 * ATmega164A/PA/324A/PA/644A/PA/1284/P

Unpack VEduino folder into `libraries' directory of the Arduino IDE Software.
See either `VEduino_Timer` Example in order to learn how to use this library with your sketches.

(D) Developed by Andrey Sharoyko <vanyamboe@gmail.com>, 2011-2012.
This software is free software. See COPYING for license information.

Thank you for choosing VEduino Library. Have a nice blink! =)

