/*
 * externalmemory.h
 *
 *  Created on: 01.11.2012
 *      Author: andrey
 */

#ifndef EXTERNALMEMORY_H_
#define EXTERNALMEMORY_H_

/**
 *  External Memory Control class.
 */
class ExtMemory: public AVR_EXTMEM
{
public:
	typedef enum {
		NO_SPLIT = 0,
		x4000,
		x6000,
		x8000,
		xA000,
		xC000,
		xE000
	} Split;
	typedef enum {
		NO_WAIT = 0,
		WS_1_0,
		WS_2_0,
		WS_2_1
	} WaitState;
	typedef enum {
		xFF = 0,
		x7F,
		x3F,
		x1F,
		x0F,
		x07,
		x03,
		x01,
		x00
	} HighMask;
public:
	bool enabled() const;
	void enable();
	void disable();
	Split split() const;
	void setSplit(Split val);
	WaitState waitState0() const;
	void setWaitState0(WaitState val);
	WaitState waitState1() const;
	void setWaitState1(WaitState val);
	bool busKeeperEnabled() const;
	void enableBusKeeper();
	void disableBusKeeper();
	HighMask highMask() const;
	void setHighMask(HighMask val);
};

inline bool ExtMemory::enabled() const
{
	return REG_(xmcra).sre;
}
inline void ExtMemory::enable()
{
	REG_(xmcra).sre = true;
}
inline void ExtMemory::disable()
{
	REG_(xmcra).sre = false;
}
inline ExtMemory::Split ExtMemory::split() const
{
	return (Split) REG_(xmcra).srl;
}
inline void ExtMemory::setSplit(Split val)
{
	REG_(xmcra).srl = val;
}
inline ExtMemory::WaitState ExtMemory::waitState0() const
{
	return (WaitState) REG_(xmcra).srw0;
}
inline void ExtMemory::setWaitState0(WaitState val)
{
	REG_(xmcra).srw0 = val;
}
inline ExtMemory::WaitState ExtMemory::waitState1() const
{
	return (WaitState) REG_(xmcra).srw1;
}
inline void ExtMemory::setWaitState1(WaitState val)
{
	REG_(xmcra).srw1 = val;
}
inline bool ExtMemory::busKeeperEnabled() const
{
	return REG_(xmcrb).xmbk;
}
inline void ExtMemory::enableBusKeeper()
{
	REG_(xmcrb).xmbk = true;
}
inline void ExtMemory::disableBusKeeper()
{
	REG_(xmcrb).xmbk = false;
}
inline ExtMemory::HighMask ExtMemory::highMask() const
{
	return (HighMask) REG_(xmcrb).xmm;
}
inline void ExtMemory::setHighMask(HighMask val)
{
	REG_(xmcrb).xmm = val;
}


#endif /* EXTERNALMEMORY_H_ */
