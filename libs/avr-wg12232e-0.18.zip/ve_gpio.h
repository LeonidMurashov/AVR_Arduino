/**
 * pin.h
 *
 *  Created on: 21.01.2012
 *      Author: andrey
 */

#ifndef GPIO_H_
#define GPIO_H_

/**
 *  General Purpose I/O class.
 */
class GPIO: public AVR_GPIO
{
public:
    void setModeInput(uint8_t _pin);
    void setModeInput();
    void setModeOutput(uint8_t _pin);
    void setModeOutput();
    void pullupOn(uint8_t _pin);
    void pullupOn();
    void pullupOff(uint8_t _pin);
    void pullupOff();
    void setHigh(uint8_t _pin);
    void setLow(uint8_t _pin);
    bool isLow(uint8_t _pin);
    bool isHigh(uint8_t _pin);
    GPIO& operator <<(uint8_t _data);
    GPIO& operator =(uint8_t _data);
    unsigned char read() const;
};

inline void GPIO::setModeInput(uint8_t _pin)
{
    REG(ddr).reset(_pin);
}

inline void GPIO::setModeInput()
{
    REG(ddr) = 0;
}

inline void GPIO::setModeOutput(uint8_t _pin)
{
    REG(ddr).set(_pin);
}

inline void GPIO::setModeOutput()
{
    REG(ddr) = 0xFF;
}

inline void GPIO::pullupOn(uint8_t _pin)
{
    setHigh(_pin);
}

inline void GPIO::pullupOn()
{
    REG(port) = 0xFF;
}

inline void GPIO::pullupOff(uint8_t _pin)
{
    setLow(_pin);
}

inline void GPIO::pullupOff()
{
    REG(port) = 0;
}

inline void GPIO::setHigh(uint8_t _pin)
{
    REG(port).set(_pin);
}

inline void GPIO::setLow(uint8_t _pin)
{
    REG(port).reset(_pin);
}

inline bool GPIO::isLow(uint8_t _pin)
{
    return !isHigh(_pin);
}

inline bool GPIO::isHigh(uint8_t _pin)
{
    return REG(pin).isSet(_pin);
}

inline GPIO& GPIO::operator <<(uint8_t _data)
{
    REG(port) = _data;
    return (*this);
}

inline GPIO& GPIO::operator =(uint8_t _data)
{
    REG(port) = _data;
    return (*this);
}

inline unsigned char GPIO::read() const
{
    return REG(pin);
}

#define DECLARE_GPIO_MTHD_VOID(_funcName) \
	inline void _funcName(GPIO& gpio, uint8_t pin) \
	{ \
		gpio._funcName(pin); \
	}
#define DECLARE_GPIO_MTHD(_result, _funcName) \
	inline _result _funcName(GPIO& gpio, uint8_t pin) \
	{ \
		return gpio._funcName(pin); \
	} \

DECLARE_GPIO_MTHD_VOID(setModeOutput)
DECLARE_GPIO_MTHD_VOID(setModeInput)
DECLARE_GPIO_MTHD_VOID(setHigh)
DECLARE_GPIO_MTHD_VOID(setLow)
DECLARE_GPIO_MTHD_VOID(pullupOn)
DECLARE_GPIO_MTHD_VOID(pullupOff)
DECLARE_GPIO_MTHD(bool, isLow)
DECLARE_GPIO_MTHD(bool, isHigh)

#endif /* GPIO_H_ */
