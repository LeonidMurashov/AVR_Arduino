/*
 * pinchangeinterruptcontrol.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef PINCHANGEINTERRUPTCONTROL_H_
#define PINCHANGEINTERRUPTCONTROL_H_

/**
 *  Pin Change Interrupt Control class.
 */
class PinChangeControl: public AVR_PCICTRL
{
public:
	bool isInt0Enabled() const;
	void enableInt0();
	void disableInt0();

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
	bool isInt1Enabled() const;
	void enableInt1();
	void disableInt1();
	bool isInt2Enabled() const;
	void enableInt2();
	void disableInt2();
#endif

#if	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
	bool isInt3Enabled() const;
	void enableInt3();
	void disableInt3();
#endif
};

inline bool PinChangeControl::isInt0Enabled() const
{
	return REG_(pcicr).pcie0;
}
inline void PinChangeControl::enableInt0()
{
	REG_(pcicr).pcie0 = true;
}
inline void PinChangeControl::disableInt0()
{
	REG_(pcicr).pcie0 = false;
}

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
inline bool PinChangeControl::isInt1Enabled() const
{
	return REG_(pcicr).pcie1;
}
inline void PinChangeControl::enableInt1()
{
	REG_(pcicr).pcie1 = true;
}
inline void PinChangeControl::disableInt1()
{
	REG_(pcicr).pcie1 = false;
}
inline bool PinChangeControl::isInt2Enabled() const
{
	return REG_(pcicr).pcie2;
}
inline void PinChangeControl::enableInt2()
{
	REG_(pcicr).pcie2 = true;
}
inline void PinChangeControl::disableInt2()
{
	REG_(pcicr).pcie2 = false;
}
#endif

#if defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
inline bool PinChangeControl::isInt3Enabled() const
{
	return REG_(pcicr).pcie3;
}
inline void PinChangeControl::enableInt3()
{
	REG_(pcicr).pcie3 = true;
}
inline void PinChangeControl::disableInt3()
{
	REG_(pcicr).pcie3 = false;
}
#endif

#endif /* PINCHANGEINTERRUPTCONTROL_H_ */
