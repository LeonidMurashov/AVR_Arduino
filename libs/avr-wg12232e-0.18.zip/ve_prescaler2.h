/**
 * prescaler2.h
 *
 *  Created on: 10.02.2012
 *      Author: andrey
 */

#ifndef PRESCALER2_H_
#define PRESCALER2_H_

/**
 *  8-bit Timer/Counter 2 Prescaler class.
 */
class Prescaler2
{
public:
    typedef enum
    {
        Stopped = 0,
        Prescaler_1 = 1,
        Prescaler_8 = 2,
        Prescaler_32 = 3,
        Prescaler_64 = 4,
        Prescaler_128 = 5,
        Prescaler_256 = 6,
        Prescaler_1024 = 7
    } ClkSelect;
public:
    static uint16_t prescaler(ClkSelect _cksel);
};

inline uint16_t Prescaler2::prescaler(ClkSelect _cksel)
{
    switch (_cksel)
    {
    case Prescaler_8:
        return 8;
    case Prescaler_32:
        return 32;
    case Prescaler_64:
        return 64;
    case Prescaler_128:
        return 128;
    case Prescaler_256:
        return 256;
    case Prescaler_1024:
        return 1024;
    default:
        return 1;
    }
}

#endif /* PRESCALER2_H_ */
