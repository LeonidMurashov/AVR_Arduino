/*
 * power.h
 *
 *  VE_AVR Library Power Reduction Header.
 *
 *  Created on: 12.05.2012
 *      Author: andrey
 */

#ifndef POWER_H_
#define POWER_H_

/**
 *  Power Reduction class.
 */
class Power : public AVR_POWER
{
public:
	bool isAdcOn() const;
    void adcOn();
    void adcOff();
    bool isSpiOn() const;
    void spiOn();
    void spiOff();
    bool isTimer1On() const;
    void timer1On();
    void timer1Off();

#if defined(VE_ATmega328P) || \
    defined(VE_ATmega2560) || \
    defined(VE_ATmega325) || \
    defined(VE_ATmega644PA) || \
    defined(VE_ATmega1284P)
    bool isUsart0On() const;
    void usart0On();
    void usart0Off();
#endif

#if defined(VE_ATmega328P) || \
    defined(VE_ATmega2560) || \
    defined(VE_ATmega32U4) || \
    defined(VE_ATmega644PA) || \
    defined(VE_ATmega1284P)
    bool isTimer0On() const;
    void timer0On();
    void timer0Off();
    bool isTwiOn() const;
    void twiOn();
    void twiOff();
#endif

#if defined(VE_ATmega328P) || \
    defined(VE_ATmega2560) || \
    defined(VE_ATmega32U4) || \
    defined(VE_ATmega644PA) || \
    defined(VE_ATmega1284P)
    bool isTimer2On() const;
    void timer2On();
    void timer2Off();
#endif

#if defined(VE_ATmega2560) || \
    defined(VE_ATmega32U4) || \
    defined(VE_ATmega644PA) || \
    defined(VE_ATmega1284P)
    bool isUsart1On() const;
    void usart1On();
    void usart1Off();
#endif

#if defined(VE_ATmega2560) || \
    defined(VE_ATmega32U4) || \
    defined(VE_ATmega1284P)
    bool isTimer3On() const;
    void timer3On();
    void timer3Off();
#endif

#if defined(VE_ATmega2560) || \
    defined(VE_ATmega32U4)
    bool isTimer4On() const;
    void timer4On();
    void timer4Off();
#endif

#if defined(VE_ATmega2560)
    bool isTimer5On() const;
    void timer5On();
    void timer5Off();
    bool isUsart2On() const;
    void usart2On();
    void usart2Off();
    bool isUsart3On() const;
    void usart3On();
    void usart3Off();
#endif

#if defined(VE_ATmega32U4)
    bool isUsbOn() const;
    void usbOn();
    void usbOff();
#endif
};

inline bool Power::isAdcOn() const
{
	return !REG_(prr0).pradc;
}
inline void Power::adcOn()
{
    DEV_ADC.disable();
    REG_(prr0).pradc = false;
}
inline void Power::adcOff()
{
	DEV_ADC.disable();
    REG_(prr0).pradc = true;
}
inline bool Power::isSpiOn() const
{
	return !REG_(prr0).prspi;
}
inline void Power::spiOn()
{
    REG_(prr0).prspi = false;
}
inline void Power::spiOff()
{
    REG_(prr0).prspi = true;
}
inline bool Power::isTimer1On() const
{
	return !REG_(prr0).prtim1;
}
inline void Power::timer1On()
{
    REG_(prr0).prtim1 = false;
}
inline void Power::timer1Off()
{
    REG_(prr0).prtim1 = true;
}

#if defined(VE_ATmega328P) || \
    defined(VE_ATmega2560) || \
    defined(VE_ATmega325) || \
    defined(VE_ATmega644PA) || \
    defined(VE_ATmega1284P)
inline bool Power::isUsart0On() const
{
	return !REG_(prr0).prusart0;
}
inline void Power::usart0On()
{
    REG_(prr0).prusart0 = false;
}
inline void Power::usart0Off()
{
    REG_(prr0).prusart0 = true;
}
#endif

#if defined(VE_ATmega328P) || \
     defined(VE_ATmega2560) || \
     defined(VE_ATmega32U4) || \
     defined(VE_ATmega644PA) || \
     defined(VE_ATmega1284P)
inline bool Power::isTimer0On() const
{
	return !REG_(prr0).prtim0;
}
inline void Power::timer0On()
{
    REG_(prr0).prtim0 = false;
}
inline void Power::timer0Off()
{
    REG_(prr0).prtim0 = true;
}
inline bool Power::isTwiOn() const
{
	return !REG_(prr0).prtwi;
}
inline void Power::twiOn()
{
    REG_(prr0).prtwi = false;
}
inline void Power::twiOff()
{
    REG_(prr0).prtwi = true;
}
#endif

#if defined(VE_ATmega328P) || \
     defined(VE_ATmega2560) || \
     defined(VE_ATmega32U4) || \
     defined(VE_ATmega644PA) || \
     defined(VE_ATmega1284P)
inline bool Power::isTimer2On() const
{
	return !REG_(prr0).prtim2;
}
inline void Power::timer2On()
{
    REG_(prr0).prtim2 = false;
}
inline void Power::timer2Off()
{
    REG_(prr0).prtim2 = true;
}
#endif

#if defined(VE_ATmega2560) || \
    defined(VE_ATmega32U4) || \
    defined(VE_ATmega1284P)
inline bool Power::isTimer3On() const
{
	return !REG_(prr1).prtim3;
}
inline void Power::timer3On()
{
    REG_(prr1).prtim3 = false;
}
inline void Power::timer3Off()
{
    REG_(prr1).prtim3 = true;
}
#endif

#if defined(VE_ATmega2560) || \
    defined(VE_ATmega32U4)
inline bool Power::isTimer4On() const
{
	return !REG_(prr1).prtim4;
}
inline void Power::timer4On()
{
    REG_(prr1).prtim4 = false;
}
inline void Power::timer4Off()
{
    REG_(prr1).prtim4 = true;
}
#endif

#if defined(VE_ATmega2560) || \
    defined(VE_ATmega32U4)
inline bool Power::isUsart1On() const
{
	return !REG_(prr1).prusart1;
}
inline void Power::usart1On()
{
    REG_(prr1).prusart1 = false;
}
inline void Power::usart1Off()
{
    REG_(prr1).prusart1 = true;
}
#endif

#if defined(VE_ATmega1284P)
inline bool Power::isUsart1On() const
{
	return !REG_(prr0).prusart1;
}
inline void Power::usart1On()
{
    REG_(prr0).prusart1 = false;
}
inline void Power::usart1Off()
{
    REG_(prr0).prusart1 = true;
}
#endif

#if defined(VE_ATmega2560)
inline bool Power::isTimer5On() const
{
	return !REG_(prr1).prtim5;
}
inline void Power::timer5On()
{
    REG_(prr1).prtim5 = false;
}
inline void Power::timer5Off()
{
    REG_(prr1).prtim5 = true;
}
inline bool Power::isUsart2On() const
{
	return !REG_(prr1).prusart2;
}
inline void Power::usart2On()
{
    REG_(prr1).prusart2 = false;
}
inline void Power::usart2Off()
{
    REG_(prr1).prusart2 = true;
}
inline bool Power::isUsart3On() const
{
	return !REG_(prr1).prusart3;
}
inline void Power::usart3On()
{
    REG_(prr1).prusart3 = false;
}
inline void Power::usart3Off()
{
    REG_(prr1).prusart3 = true;
}
#endif

#if defined(VE_ATmega32U4)
inline bool Power::isUsbOn() const
{
	return !REG_(prr1).prusb;
}
inline void Power::usbOn()
{
    REG_(prr1).prusb = false;
}
inline void Power::usbOff()
{
    REG_(prr1).prusb = true;
}
#endif

#endif /* POWER_H_ */
