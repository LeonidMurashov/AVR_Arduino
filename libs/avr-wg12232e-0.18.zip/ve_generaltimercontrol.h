/*
 * generaltimercontrol.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef GENERALTIMERCONTROL_H_
#define GENERALTIMERCONTROL_H_

/**
 *  General Timer/Counter Control class.
 */
class GeneralTimerControl : public AVR_GTCCRS
{
public:
	bool isSynchronizationModeOn() const;
	void synchronizationModeOn();
	void synchronizationModeOff();
	void timer0PrescalerReset();
	void timer2PrescalerReset();
};

inline bool GeneralTimerControl::isSynchronizationModeOn() const
{
	return REG_(gtccr).tsm;
}
inline void GeneralTimerControl::synchronizationModeOn()
{
	REG_(gtccr).tsm = true;
}
inline void GeneralTimerControl::synchronizationModeOff()
{
	REG_(gtccr).tsm = false;
}
inline void GeneralTimerControl::timer0PrescalerReset()
{
	REG_(gtccr).psrsync = true;
}
inline void GeneralTimerControl::timer2PrescalerReset()
{
	REG_(gtccr).psrasy = true;
}

#endif /* GENERALTIMERCONTROL_H_ */
