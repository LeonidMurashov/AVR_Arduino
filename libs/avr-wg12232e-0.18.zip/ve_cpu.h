/**
 * cpu.h
 *
 *  Created on: 23.01.2012
 *      Author: andrey
 */

#ifndef CPU_H_
#define CPU_H_

inline bool isInterruptsEnabled()
{
	return DEV_SREG.intEn;
}
inline void enableInterrupts()
{
	__asm__ __volatile__("sei");
}
inline void disableInterrupts()
{
	__asm__ __volatile__("cli");
}
inline bool isHalfCarry()
{
    return DEV_SREG.halfCarry;
}
inline void setHalfCarry()
{
	__asm__ __volatile__("seh");
}
inline void clearHalfCarry()
{
	__asm__ __volatile__("clh");
}
inline bool isSign()
{
    return DEV_SREG.sign;
}
inline void setSign()
{
	__asm__ __volatile__("ses");
}
inline void clearSign()
{
	__asm__ __volatile__("cls");
}
inline bool isTwoCompOverflow()
{
	return DEV_SREG.twoCompOvf;
}
inline void setTwoCompOverflow()
{
	__asm__ __volatile__("sev");
}
inline void clearTwoCompOverflow()
{
	__asm__ __volatile__("clv");
}
inline bool isNegative()
{
    return DEV_SREG.negative;
}
inline void setNegative()
{
	__asm__ __volatile__("sen");
}
inline void clearNegative()
{
	__asm__ __volatile__("cln");
}
inline bool isZero()
{
    return DEV_SREG.zero;
}
inline void setZero()
{
	__asm__ __volatile__("sez");
}
inline void clearZero()
{
	__asm__ __volatile__("clz");
}
inline bool isCarry()
{
    return DEV_SREG.carry;
}
inline void setCarry()
{
	__asm__ __volatile__("sec");
}
inline void clearCarry()
{
	__asm__ __volatile__("clc");
}

#endif /* CPU_H_ */
