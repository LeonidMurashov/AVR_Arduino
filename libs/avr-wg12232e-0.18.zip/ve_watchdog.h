/*
 * watchdog.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef WATCHDOG_H_
#define WATCHDOG_H_

/**
 *  Watchdog Timer class.
 */
class Watchdog: public AVR_WATCHDOG
{
#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega32U4) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
public:
	typedef enum {
		OSC_2K = 0,
		OSC_4K,
		OSC_8K,
		OSC_16K,
		OSC_32K,
		OSC_64K,
		OSC_128K,
		OSC_256K,
		OSC_512K,
		OSC_1024K
	} Prescaler;
#endif

#if defined(VE_ATmega325) || \
	defined(VE_ATmega32)
public:
	typedef enum {
		OSC_16K = 0,
		OSC_32K,
		OSC_64K,
		OSC_128K,
		OSC_256K,
		OSC_512K,
		OSC_1024K,
		OSC_2048K
	} Prescaler;
#endif
public:
	Prescaler prescaler() const;
	void setPrescaler(Prescaler val);
	bool isChangeEnabled() const;
	void enableChange();

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
	bool isInt() const;
	void clearInt();
	bool isIntEnabled() const;
	void enableInt();
	void disableInt();
	bool isResetEnabled() const;
	void enableReset();
	void disableReset();
#endif

#if defined(VE_ATmega325) || \
	defined(VE_ATmega32)
	bool isEnabled() const;
	void enable();
	void disable();
#endif
};

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
inline Watchdog::Prescaler Watchdog::prescaler() const
{
	return (Prescaler) ((REG_(wdtcsr).wdp3 << 3) | REG_(wdtcsr).wdp);
}
inline void Watchdog::setPrescaler(Prescaler val)
{
	register unsigned char wdp3 = val & 8;
	register unsigned char wdp = val & 7;
	register unsigned char sreg = SREG;
	disableInterrupts();
	enableChange();
	REG_(wdtcsr).wdp3 = wdp3;
	REG_(wdtcsr).wdp = wdp;
	SREG = sreg;
}
inline bool Watchdog::isInt() const
{
	return REG_(wdtcsr).wdif;
}
inline void Watchdog::clearInt()
{
	REG_(wdtcsr).wdif = true;
}
inline bool Watchdog::isIntEnabled() const
{
	return REG_(wdtcsr).wdie;
}
inline void Watchdog::enableInt()
{
	REG_(wdtcsr).wdie = true;
}
inline void Watchdog::disableInt()
{
	REG_(wdtcsr).wdie = false;
}
inline bool Watchdog::isChangeEnabled() const
{
	return REG_(wdtcsr).wce;
}
inline void Watchdog::enableChange()
{
	REG_(wdtcsr).wce = true;
}
inline bool Watchdog::isResetEnabled() const
{
	return REG_(wdtcsr).wde;
}
inline void Watchdog::enableReset()
{
	REG_(wdtcsr).wde = true;
}
inline void Watchdog::disableReset()
{
	register unsigned char sreg = SREG;
	disableInterrupts();
	DEV_MCU.clearWatchdogReset();
	enableChange();
	REG_(wdtcsr).wde = false;
	SREG = sreg;
}
#endif

#if defined(VE_ATmega325) || \
	defined(VE_ATmega32)
inline Watchdog::Prescaler Watchdog::prescaler() const
{
	return (Prescaler) REG_(wdtcsr).wdp;
}
inline void Watchdog::setPrescaler(Prescaler val)
{
	register unsigned char sreg = SREG;
	disableInterrupts();
	enableChange();
	REG_(wdtcsr).wdp = val;
	SREG = sreg;
}
inline bool Watchdog::isChangeEnabled() const
{
	return REG_(wdtcsr).wdce;
}
inline void Watchdog::enableChange()
{
	__asm__ __volatile__ ("wdr");
	REG(wdtcsr) |= _BV(WDCE) | _BV(WDE);
}
inline bool Watchdog::isEnabled() const
{
	return REG_(wdtcsr).wde;
}
inline void Watchdog::enable()
{
	REG_(wdtcsr).wde = true;
}
inline void Watchdog::disable()
{
	register unsigned char sreg = SREG;
	disableInterrupts();
	enableChange();
	REG(wdtcsr) |= _BV(WDCE) | _BV(WDE);
	REG(wdtcsr) = 0;
	SREG = sreg;
}
#endif

#endif /* WATCHDOG_H_ */
