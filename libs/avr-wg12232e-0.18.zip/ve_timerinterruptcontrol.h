/**
 * timerinterruptcontrol.h
 *
 *  Created on: 27.01.2012
 *      Author: andrey
 */

#ifndef TIMERINTERRUPTCONTROL_H_
#define TIMERINTERRUPTCONTROL_H_


template<typename _TIMSK_REG>
class TimerInterruptControlT: public _TIMSK_REG
{
public:
    bool isOverflowIntEnabled() const
    {
        return this->m_reg.toie;
    }
    void overflowIntEnable()
    {
        this->m_reg.toie = true;
    }
    void overflowIntDisable()
    {
        this->m_reg.toie = false;
    }
    bool isOutCompIntEnabledA() const
    {
        return this->m_reg.ociea;
    }
    void outCompIntEnableA()
    {
        this->m_reg.ociea = true;
    }
    void outCompIntDisableA()
    {
        this->m_reg.ociea = false;
    }
    bool isOutCompIntEnabledB() const
    {
        return this->m_reg.ocieb;
    }
    void outCompIntEnableB()
    {
        this->m_reg.ocieb = true;
    }
    void outCompIntDisableB()
    {
        this->m_reg.ocieb = false;
    }
#if defined(VE_ATmega2560) || \
	defined(VE_ATmega32U4)
    bool isOutCompIntEnabledC() const
    {
        return this->m_reg.ociec;
    }
    void outCompIntEnableC()
    {
        this->m_reg.ociec = true;
    }
    void outCompIntDisableC()
    {
        this->m_reg.ociec = false;
    }
#endif
#if defined(VE_ATmega32U4)
    bool isOutCompIntEnabledD() const
    {
        return this->m_reg.ocied;
    }
    void outCompIntEnableD()
    {
        this->m_reg.ocied = true;
    }
    void outCompIntDisableD()
    {
        this->m_reg.ocied = false;
    }
#endif
    bool isInputCaptIntEnabled() const
    {
        return this->m_reg.icie;
    }
    void inputCaptIntEnable()
    {
        this->m_reg.icie = true;
    }
    void inputCaptIntDisable()
    {
        this->m_reg.icie = false;
    }
};

#if defined(VE_ATmega325) || \
	defined(VE_ATmega328P) || \
	defined(VE_ATmega32U4) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
typedef TimerInterruptControlT<TIMSK_REG> TimerIntCtrl;
#endif

#if defined(VE_ATmega32)
typedef TimerInterruptControlT<TIMSK0_REG> TimerIntCtrl0;
typedef TimerInterruptControlT<TIMSK2_REG> TimerIntCtrl2;
#endif

typedef TimerInterruptControlT<TIMSKW_REG> TimerIntCtrlW;

#if defined(VE_ATmega32U4)
typedef TimerInterruptControlT<TIMSKHS_REG> TimerIntCtrlHS;
#endif

#endif /* TIMERINTERRUPTCONTROL_H_ */
