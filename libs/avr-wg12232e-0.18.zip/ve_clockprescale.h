/*
 * clockprescale.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef CLOCKPRESCALE_H_
#define CLOCKPRESCALE_H_

/**
 *  System Clock Prescaler class.
 */
class ClockPrescale : public AVR_CLKPR
{
public:
	typedef enum {
		DIV_1 = 0,
		DIV_2,
		DIV_4,
		DIV_8,
		DIV_16,
		DIV_32,
		DIV_64,
		DIV_128,
		DIV_256
	} Factor;
public:
	Factor factor() const;
	void setFactor(Factor val);
protected:
	void enableChange();
};

inline ClockPrescale::Factor ClockPrescale::factor() const
{
	return (Factor) REG_(clkpr);
}
inline void ClockPrescale::setFactor(Factor val)
{
	register unsigned char sreg = SREG;
	disableInterrupts();
	enableChange();
	REG_(clkpr) = val;
	SREG = sreg;
}
inline void ClockPrescale::enableChange()
{
	REG_(clkpr) = _BV(CLKPCE);
}

#endif /* CLOCKPRESCALE_H_ */
