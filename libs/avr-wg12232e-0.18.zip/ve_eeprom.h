/*
 * eeprom.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef EEPROM_H_
#define EEPROM_H_

/**
 *  EEPROM class.
 */
class EEPROM : public AVR_EEPROM
{
public:
	class ptr
	{
	public:
		char operator =(char data);
		uint8_t operator =(uint8_t data);
		uint16_t operator = (uint16_t data);
		ptr& operator >> (char &ch);
		ptr& operator >> (uint8_t &ch);
		ptr& operator >> (uint16_t &wd);
		ptr& operator << (char data);
		ptr& operator << (uint8_t data);
		ptr& operator << (uint16_t data);
	};
public:
	bool isInterruptEnabled() const;
	void enableInterrupt();
	void disableInterrupt();
	ptr& operator [] (uintptr_t address);
protected:
	void enableMasterWrite();
	bool isBusyWrite() const;
	void enableWrite();
	void enableRead();

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560)
public:
	typedef enum {
		ERASE_WRITE = 0,
		ERASE_ONLY,
		WRITE_ONLY
	} ProgMode;
	ProgMode progMode() const;
	void setProgMode(ProgMode mode);
#endif
};

inline EEPROM::ptr& EEPROM::operator [] (uintptr_t address)
{
	EEPROM::ptr* p = (EEPROM::ptr*) address;
	return *p;
}
inline char EEPROM::ptr::operator =(char data)
{
	while (DEV_EEPROM.isBusyWrite());
	while (DEV_SPM.isSelfProgEnabled());
	register uint8_t sreg = SREG;
	disableInterrupts();
	DEV_EEPROM.eear.m_reg = (uintptr_t) this;
	DEV_EEPROM.eedr.m_reg = data;
	DEV_EEPROM.enableMasterWrite();
	DEV_EEPROM.enableWrite();
	SREG = sreg;	// Restoring Interrupts Flag
	return data;
}
inline uint8_t EEPROM::ptr::operator =(uint8_t data)
{
	return operator = ((char) data);
}
inline uint16_t EEPROM::ptr::operator = (uint16_t data)
{
	EEPROM::ptr* p = this;
	p->operator = ((char) data);
	++p;
	p->operator = ((char) (data >> 8));
	return data;
}
inline EEPROM::ptr& EEPROM::ptr::operator >> (char &ch)
{
	while (DEV_EEPROM.isBusyWrite());
	while (DEV_SPM.isSelfProgEnabled());
	register uint8_t sreg = SREG;
	disableInterrupts();
	DEV_EEPROM.eear.m_reg = (uintptr_t) this;
	DEV_EEPROM.enableRead();
	ch = DEV_EEPROM.eedr.m_reg;
	SREG = sreg;	// Restoring Interrupts Flag
	EEPROM::ptr* p = this;
	++p;
	return (*p);
}
inline EEPROM::ptr& EEPROM::ptr::operator >> (uint8_t &ch)
{
	EEPROM::ptr* p = this;
	p->operator >> ((char&) ch);
	++p;
	return (*p);
}
inline EEPROM::ptr& EEPROM::ptr::operator >> (uint16_t &wd)
{
	EEPROM::ptr* p = this;
	char* pwd = (char*) &wd;
	p->operator >> (*pwd);
	++p; ++pwd;
	p->operator >> (*pwd);
	++p;
	return (*p);
}
inline EEPROM::ptr& EEPROM::ptr::operator << (char data)
{
	this->operator = (data);
	EEPROM::ptr* p = this;
	++p;
	return (*p);
}
inline EEPROM::ptr& EEPROM::ptr::operator << (uint8_t data)
{
	this->operator = (data);
	EEPROM::ptr* p = this;
	++p;
	return (*p);
}
inline EEPROM::ptr& EEPROM::ptr::operator << (uint16_t data)
{
	this->operator = (data);
	EEPROM::ptr* p = this;
	p += 2;
	return (*p);
}
inline bool EEPROM::isInterruptEnabled() const
{
	return REG_(eecr).eerie;
}
inline void EEPROM::enableInterrupt()
{
	REG_(eecr).eerie = true;
}
inline void EEPROM::disableInterrupt()
{
	REG_(eecr).eerie = false;
}
inline void EEPROM::enableMasterWrite()
{
	REG_(eecr).eempe = true;
}
inline bool EEPROM::isBusyWrite() const
{
	return REG_(eecr).eepe;
}
inline void EEPROM::enableWrite()
{
	REG_(eecr).eepe = true;
}
inline void EEPROM::enableRead()
{
	REG_(eecr).eere = true;
}

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560)
inline 	EEPROM::ProgMode EEPROM::progMode() const
{
	return (ProgMode) REG_(eecr).eepm;
}
inline void EEPROM::setProgMode(ProgMode mode)
{
	REG_(eecr).eepm = mode;
}
#endif

#endif /* EEPROM_H_ */
