/**
 * fifo.h
 *
 *  Created on: 22.01.2012
 *      Author: andrey
 */

#ifndef FIFO_H_
#define FIFO_H_

/**
 *  FIFO class template.
 */
template<typename _T, typename _IndexT>
class FIFO
{
public:
    /**
     *  FIFO index class.
     */
    class Index
    {
    protected:
        volatile _IndexT m_value;
        _IndexT m_min;
        _IndexT m_max;
    public:
        Index(const _IndexT& _min, const _IndexT& _max) :
            m_value(_min), m_min(_min), m_max(_max)
        {
        }
        Index& operator +=(int _incr)
        {
            m_value += _incr;
            if (m_value >= m_max)
                m_value = m_min;
            return (*this);
        }
        bool operator !=(const Index& cmp) const
        {
            return (m_value != cmp.m_value);
        }
        operator _IndexT() const
        {
            return m_value;
        }
    };
protected:
    Index nRead;
    Index nWrite;
    _T *pData;
public:
    FIFO(_T* _data, uint8_t _size) :
        nRead(0, _size), nWrite(0, _size), pData(_data)
    {
    }
    bool gotNewData() const
    {
        return (nRead != nWrite);
    }
    FIFO& push(const _T& _item)
    {
        pData[nWrite] = _item;
        nWrite += 1;
        return (*this);
    }
    _T pop()
    {
        _T ret = pData[nRead];
        nRead += 1;
        return ret;
    }
};

typedef FIFO<uint8_t, uint8_t> U8fifo;

#endif /* FIFO_H_ */
