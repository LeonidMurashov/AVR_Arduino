/*
 * storeprogrammemory.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef STOREPROGRAMMEMORY_H_
#define STOREPROGRAMMEMORY_H_

/**
 *  Store Program Memory class.
 */
class StoreProgMem : public AVR_SPM
{
public:
	bool isInterruptEnabled() const;
	void enableInterrupt();
	void disableInterrupt();
	bool isSectionBusy() const;
	bool isSectionReadEnabled() const;
	bool isSelfProgEnabled() const;
#if defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
	void signatureRowRead();
#endif
};

inline bool StoreProgMem::isInterruptEnabled() const
{
	return REG_(spmcsr).spmie;
}
inline void StoreProgMem::enableInterrupt()
{
	REG_(spmcsr).spmie = true;
}
inline void StoreProgMem::disableInterrupt()
{
	REG_(spmcsr).spmie = false;
}
inline bool StoreProgMem::isSectionBusy() const
{
	return REG_(spmcsr).rwwsb;
}
inline bool StoreProgMem::isSectionReadEnabled() const
{
	return REG_(spmcsr).rwwsre;
}
inline bool StoreProgMem::isSelfProgEnabled() const
{
	return REG_(spmcsr).selfprgen;
}
#if defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
inline void StoreProgMem::signatureRowRead()
{
	REG(spmcsr) |= _BV(SPMEN) | _BV(SIGRD);
}
#endif

#endif /* STOREPROGRAMMEMORY_H_ */
