/*
 * pinchangeinterruptmask.h
 *
 *  Created on: 01.11.2012
 *      Author: andrey
 */

#ifndef PINCHANGEINTERRUPTMASK_H_
#define PINCHANGEINTERRUPTMASK_H_

#define PCMT_DECLARE(num) \
	inline bool isInt##num##Enabled() const { \
		return this->m_reg.pcint##num; \
	} \
	inline void enableInt##num() { \
		this->m_reg.pcint##num = true; \
	} \
	inline void disableInt##num() { \
		this->m_reg.pcint##num = true; \
	}

/**
 *  Pin Change Interrupt Mask class template.
 */
template <typename _PCMASK_REG>
class PinChangeMaskT: public _PCMASK_REG
{
public:
	PCMT_DECLARE(0)
	PCMT_DECLARE(1)
	PCMT_DECLARE(2)
	PCMT_DECLARE(3)
	PCMT_DECLARE(4)
	PCMT_DECLARE(5)
	PCMT_DECLARE(6)
	PCMT_DECLARE(7)
};

typedef PinChangeMaskT<PCMSK_REG> PinChangeMask;
//typedef PinChangeMaskT<AVR_PCMSK> PinChangeMask;

#define PCM_DECLARE(pin, mask, bit) \
inline bool isPinChangeInt##pin##Enabled() { \
	return DEV_PCIMASK##mask.isInt##bit##Enabled(); \
} \
inline void enablePinChangeInt##pin() { \
	DEV_PCIMASK##mask.enableInt##bit(); \
} \
inline void disablePinChangeInt##pin() { \
	DEV_PCIMASK##mask.disableInt##bit(); \
}

PCM_DECLARE(0, 0, 0)
PCM_DECLARE(1, 0, 1)
PCM_DECLARE(2, 0, 2)
PCM_DECLARE(3, 0, 3)
PCM_DECLARE(4, 0, 4)
PCM_DECLARE(5, 0, 5)
PCM_DECLARE(6, 0, 6)
PCM_DECLARE(7, 0, 7)

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega325) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
PCM_DECLARE(8, 1, 0)
PCM_DECLARE(9, 1, 1)
PCM_DECLARE(10, 1, 2)
PCM_DECLARE(11, 1, 3)
PCM_DECLARE(12, 1, 4)
PCM_DECLARE(13, 1, 5)
PCM_DECLARE(14, 1, 6)
#endif

#if defined(VE_ATmega2560) || \
	defined(VE_ATmega325) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
PCM_DECLARE(15, 1, 7)
#endif

#if defined(VE_ATmega2560) || \
	defined(VE_ATmega325) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P) || \
	defined(VE_ATmega328P)
PCM_DECLARE(16, 2, 0)
PCM_DECLARE(17, 2, 1)
PCM_DECLARE(18, 2, 2)
PCM_DECLARE(19, 2, 3)
PCM_DECLARE(20, 2, 4)
PCM_DECLARE(21, 2, 5)
PCM_DECLARE(22, 2, 6)
PCM_DECLARE(23, 2, 7)
#endif

#if defined(VE_ATmega325) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
PCM_DECLARE(24, 3, 0)
PCM_DECLARE(25, 3, 1)
PCM_DECLARE(26, 3, 2)
PCM_DECLARE(27, 3, 3)
PCM_DECLARE(28, 3, 4)
PCM_DECLARE(29, 3, 5)
PCM_DECLARE(30, 3, 6)
#endif

#if defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
PCM_DECLARE(31, 3, 7)
#endif

#endif /* PINCHANGEINTERRUPTMASK_H_ */
