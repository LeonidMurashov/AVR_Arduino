/**
 * timerw.h
 *
 *  Created on: 24.01.2012
 *      Author: andrey
 */

#ifndef TIMERW_H_
#define TIMERW_H_


/**
 *  16-bit Timer/Counter class.
 */
class TimerW: public AVR_TIMERW
{
public:
    typedef enum
    {
        Disconnected = 0, Toggle = 1, Clear = 2, Set = 3
    } CompOutMode;
    typedef enum
    {
        Normal = 0,
        PhaseCorrect_8bit = 1,
        PhaseCorrect_9bit = 2,
        PhaseCorrect_10bit = 3,
        CTC_OCRA = 4,
        FastPWM_8bit = 5,
        FastPWM_9bit = 6,
        FastPWM_10bit = 7,
        PhaseFreqCorrect_ICR = 8,
        PhaseFreqCorrect_OCRA = 9,
        PhaseCorrect_ICR = 10,
        PhaseCorrect_OCRA = 11,
        CTC_ICR = 12,
        FastPWM_ICR = 14,
        FastPWM_OCRA = 15
    } WaveGenMode;
    typedef enum
    {
        Falling = false, Rising = true
    } InCaptEdge;
    typedef enum
    {
        Stopped = 0,
        Prescaler_1 = 1,
        Prescaler_8 = 2,
        Prescaler_64 = 3,
        Prescaler_256 = 4,
        Prescaler_1024 = 5,
        ExtClkFalling = 6,
        ExtClkRising = 7
    } ClkSelect;
public:
    uint16_t prescaler() const;
    uint16_t counter() const;
    void setCounter(uint16_t val);
    uint16_t outputCompareA() const;
    void setOutputCompareA(uint16_t val);
    uint16_t outputCompareB() const;
    void setOutputCompareB(uint16_t val);
    uint16_t inputCapture() const;
    void setInputCapture(uint16_t val);
    void setInputCaptureFreq(long val);
    CompOutMode compOutModeA() const;
    void setCompOutModeA(CompOutMode val);
    CompOutMode compOutModeB() const;
    void setCompOutModeB(CompOutMode val);
    WaveGenMode wavGenMode() const;
    void setWaveGenMode(WaveGenMode val);
    bool isNoiseCancelerActive() const;
    void noiseCancelerOn();
    void noiseCancelerOff();
    InCaptEdge inputCaptureEdge() const;
    void setInputCaptureEdge(InCaptEdge val);
    ClkSelect clockSelect() const;
    void setClockSelect(ClkSelect val);
    void forceOutputCompareA();
    void forceOutputCompareB();

#if defined(VE_ATmega2560) || \
 	defined(VE_ATmega32U4)
    uint16_t outputCompareC() const;
    void setOutputCompareC(uint16_t val);
    CompOutMode compOutModeC() const;
    void setCompOutModeC(CompOutMode val);
    void forceOutputCompareC();
#endif
};

inline uint16_t TimerW::prescaler() const
{
    switch (clockSelect())
    {
    case Prescaler_8:
        return 8;
    case Prescaler_64:
        return 64;
    case Prescaler_256:
        return 256;
    case Prescaler_1024:
        return 1024;
    default:
        return 1;
    }
}

inline uint16_t TimerW::counter() const
{
    return REG_(tcnt);
}

inline void TimerW::setCounter(uint16_t val)
{
    REG_(tcnt) = val;
}

inline uint16_t TimerW::outputCompareA() const
{
    return REG_(ocra);
}

inline void TimerW::setOutputCompareA(uint16_t val)
{
    REG_(ocra) = val;
}

inline uint16_t TimerW::outputCompareB() const
{
    return REG_(ocrb);
}

inline void TimerW::setOutputCompareB(uint16_t val)
{
    REG_(ocrb) = val;
}

#if defined(VE_ATmega2560) || \
 	defined(VE_ATmega32U4)
inline uint16_t TimerW::outputCompareC() const
{
    return REG_(ocrc);
}

inline void TimerW::setOutputCompareC(uint16_t val)
{
    REG_(ocrc) = val;
}

#endif

inline uint16_t TimerW::inputCapture() const
{
    return REG_(icr);
}

inline void TimerW::setInputCapture(uint16_t val)
{
    REG_(icr) = val;
}

inline void TimerW::setInputCaptureFreq(long val)
{
    long _icr = F_CPU / prescaler();
    _icr = _icr / val;
    setInputCapture(_icr);
}

inline TimerW::CompOutMode TimerW::compOutModeA() const
{
    return (TimerW::CompOutMode) REG_(tccra).coma;
}

inline void TimerW::setCompOutModeA(TimerW::CompOutMode val)
{
    REG_(tccra).coma = val;
}

inline TimerW::CompOutMode TimerW::compOutModeB() const
{
    return (TimerW::CompOutMode) REG_(tccra).comb;
}

inline void TimerW::setCompOutModeB(TimerW::CompOutMode val)
{
    REG_(tccra).comb = val;
}

#if defined(VE_ATmega2560) || \
	defined(VE_ATmega32U4)
inline TimerW::CompOutMode TimerW::compOutModeC() const
{
    return (TimerW::CompOutMode) REG_(tccra).comc;
}

inline void TimerW::setCompOutModeC(TimerW::CompOutMode val)
{
    REG_(tccra).comc = val;
}
#endif

inline TimerW::WaveGenMode TimerW::wavGenMode() const
{
	unsigned char wgm = (REG_(tccrb).wgmh << 2) | REG_(tccra).wgml;
    return (TimerW::WaveGenMode) wgm;
}

inline void TimerW::setWaveGenMode(WaveGenMode val)
{
    REG_(tccrb).wgmh = (val >> 2) & 0x03;
    REG_(tccra).wgml = val & 0x03;
}

inline bool TimerW::isNoiseCancelerActive() const
{
    return REG_(tccrb).icnc;
}

inline void TimerW::noiseCancelerOn()
{
    REG_(tccrb).icnc = true;
}

inline void TimerW::noiseCancelerOff()
{
    REG_(tccrb).icnc = false;
}

inline TimerW::InCaptEdge TimerW::inputCaptureEdge() const
{
    return (TimerW::InCaptEdge) REG_(tccrb).ices;
}

inline void TimerW::setInputCaptureEdge(TimerW::InCaptEdge val)
{
    REG_(tccrb).ices = val;
}

inline TimerW::ClkSelect TimerW::clockSelect() const
{
    return (TimerW::ClkSelect) REG_(tccrb).cs;
}

inline void TimerW::setClockSelect(TimerW::ClkSelect val)
{
    REG_(tccrb).cs = val;
}

inline void TimerW::forceOutputCompareA()
{
#if defined(VE_ATmega328P) || \
    defined(VE_ATmega2560) || \
    defined(VE_ATmega325) || \
    defined(VE_ATmega32U4)
    REG_(tccrc).foca = true;
#endif
#if defined(VE_ATmega32)
    REG_(tccra).foca = true;
#endif
}

inline void TimerW::forceOutputCompareB()
{
#if defined(VE_ATmega328P) || \
    defined(VE_ATmega2560) || \
    defined(VE_ATmega325) || \
    defined(VE_ATmega32U4)
    REG_(tccrc).focb = true;
#endif
#if defined(VE_ATmega32)
    REG_(tccra).focb = true;
#endif
}

#if defined(VE_ATmega2560) || \
	defined(VE_ATmega32U4)
inline void TimerW::forceOutputCompareC()
{
    REG_(tccrc).focc = true;
}
#endif

#endif /* TIMERW_H_ */
