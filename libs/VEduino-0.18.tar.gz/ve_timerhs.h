/*
 * timerhs.h
 *
 *  Created on: 05.12.2012
 *      Author: andrey
 */

#ifndef TIMERHS_H_
#define TIMERHS_H_

#if defined(VE_ATmega32U4)
typedef struct {
	unsigned char reserved[10];
} TIMERHS_reserved;
#define TIMERHS_PARENT		AVR_TIMERHS, private TIMERHS_reserved, public AVR_TIMERHS_OC
#endif

class TimerHS : public TIMERHS_PARENT
{
public:
    typedef enum
    {
        Disconnected = 0,
        Toggle = 1,
        Clear  = 2,
        Set    = 3
    } CompOutMode;
    typedef enum
    {
    	DIV_1 = 0,
    	DIV_2 = 1,
    	DIV_4 = 2,
    	DIV_8 = 3
    } DeadTimePrescaler;
    typedef enum
    {
    	Stopped = 0,
    	Clock_DIV_1 = 1,
    	Clock_DIV_2 = 2,
    	Clock_DIV_4 = 3,
    	Clock_DIV_8 = 4,
    	Clock_DIV_16 = 5,
    	Clock_DIV_32 = 6,
    	Clock_DIV_64 = 7,
    	Clock_DIV_128 = 8,
    	Clock_DIV_256 = 9,
    	Clock_DIV_512 = 10,
    	Clock_DIV_1024 = 11,
    	Clock_DIV_2048 = 12,
    	Clock_DIV_4096 = 13,
    	Clock_DIV_8192 = 14,
    	Clock_DIV_16384 = 15
    } Prescaler;
    typedef enum
    {
    	Falling = 0,
    	Rising = 1
    } EdgeSelect;
    typedef enum
    {
        FastPWM = 0,
        PhaseFreqCorrect = 1,
        SingleSlopePWM6  = 2,
        DualSlopePWM6    = 3
    } WaveGenMode;
    typedef enum
    {
    	nOCA = 1,
    	OCA  = 2,
    	nOCB = 4,
    	OCB  = 8,
    	nOCD = 16,
    	OCD  = 32
    } OutCompOverrideEnableBit;
public:
    CompOutMode compOutModeA() const;
    void setCompOutModeA(CompOutMode val);
    CompOutMode compOutModeB() const;
    void setCompOutModeB(CompOutMode val);
    void forceOutputCompareA();
    void forceOutputCompareB();
    bool isPWMAEnabled() const;
    void enablePWMA();
    void disablePWMA();
    bool isPWMBEnabled() const;
    void enablePWMB();
    void disablePWMB();
    bool isPWMInversionModeEnabled() const;
    void enablePWMInversionMode();
    void disablePWMInversionMode();
    void resetPrescaler();
    DeadTimePrescaler deadTimePrescaler() const;
    void setDeadTimePrescaler(DeadTimePrescaler val);
    Prescaler clockSelect() const;
    void setClockSelect(Prescaler val);
    CompOutMode compOutModeShadowA() const;
    void setCompOutModeShadowA(CompOutMode val);
    CompOutMode compOutModeShadowB() const;
    void setCompOutModeShadowB(CompOutMode val);
    CompOutMode compOutModeD() const;
    void setCompOutModeD(CompOutMode val);
    void forceOutputCompareD();
    bool isPWMDEnabled() const;
    void enablePWMD();
    void disablePWMD();
    bool isFaultProtIntEnabled() const;
    void enableFaultProtInt();
    void disableFaultProtInt();
    bool isFaultProtModeEnabled() const;
    void enableFaultProtMode();
    void disableFaultProtMode();
    bool isFaultProtNoiseCancelerOn() const;
    void setFaultProtNoiseCancelerOn();
    void setFaultProtNoiseCancelerOff();
    EdgeSelect faultProtEdgeSelect() const;
    void setFaultProtEdgeSelect(EdgeSelect val);
    bool isFaultProtAnalogCompEnabled() const;
    void enableFaultProtAnalogComp();
    void disableFaultProtAnalogComp();
    bool isFaultProtInt() const;
    WaveGenMode wavGenMode() const;
    void setWavGenMode(WaveGenMode val);
    bool isRegisterUpdateLocked() const;
    void lockRegisterUpdate();
    void unlockRegisterUpdate();
    bool isEnhancedModeOn() const;
    void setEnhancedModeOn();
    void setEnhancedModeOff();
    bool isOutCompOverrideEnableOn(OutCompOverrideEnableBit bit) const;
    void setOutCompOverrideEnableOn(OutCompOverrideEnableBit bit);
    void setOutCompOverrideEnableOff(OutCompOverrideEnableBit bit);
    uint8_t counter() const;
    void setCounter(uint8_t val);
    uint8_t outputCompareA() const;
    void setOutputCompareA(uint8_t val);
    uint8_t outputCompareB() const;
    void setOutputCompareB(uint8_t val);
    uint8_t outputCompareC() const;
    void setOutputCompareC(uint8_t val);
    uint8_t outputCompareD() const;
    void setOutputCompareD(uint8_t val);
    unsigned char deadTimeOCx() const;
    void setDeadTimeOCx(unsigned char val);
    unsigned char deadTimeNOCx() const;
    void setDeadTimeNOCx(unsigned char val);
};

inline TimerHS::CompOutMode TimerHS::compOutModeA() const
{
    return (CompOutMode) REG_(tccra).coma;
}
inline void TimerHS::setCompOutModeA(CompOutMode val)
{
    REG_(tccra).coma = val;
}
inline TimerHS::CompOutMode TimerHS::compOutModeB() const
{
    return (CompOutMode) REG_(tccra).coma;
}
inline void TimerHS::setCompOutModeB(CompOutMode val)
{
    REG_(tccra).coma = val;
}
inline void TimerHS::forceOutputCompareA()
{
    REG_(tccra).foca = true;
}
inline void TimerHS::forceOutputCompareB()
{
    REG_(tccra).focb = true;
}
inline bool TimerHS::isPWMAEnabled() const
{
	return REG_(tccra).pwma;
}
inline void TimerHS::enablePWMA()
{
	REG_(tccra).pwma = true;
}
inline void TimerHS::disablePWMA()
{
	REG_(tccra).pwma = false;
}
inline bool TimerHS::isPWMBEnabled() const
{
	return REG_(tccra).pwmb;
}
inline void TimerHS::enablePWMB()
{
	REG_(tccra).pwmb = true;
}
inline void TimerHS::disablePWMB()
{
	REG_(tccra).pwmb = false;
}
inline bool TimerHS::isPWMInversionModeEnabled() const
{
	return REG_(tccrb).pwmx;
}
inline void TimerHS::enablePWMInversionMode()
{
	REG_(tccrb).pwmx = true;;
}
inline void TimerHS::disablePWMInversionMode()
{
	REG_(tccrb).pwmx = true;
}
inline void TimerHS::resetPrescaler()
{
	REG_(tccrb).psr = true;
}
inline TimerHS::DeadTimePrescaler TimerHS::deadTimePrescaler() const
{
	return (DeadTimePrescaler) REG_(tccrb).dtps;
}
inline void TimerHS::setDeadTimePrescaler(DeadTimePrescaler val)
{
	REG_(tccrb).dtps = val;
}
inline TimerHS::Prescaler TimerHS::clockSelect() const
{
	return (Prescaler) REG_(tccrb).cs;
}
inline void TimerHS::setClockSelect(Prescaler val)
{
	REG_(tccrb).cs = val;
}
inline TimerHS::CompOutMode TimerHS::compOutModeShadowA() const
{
	return (CompOutMode) REG_(tccrc).comas;
}
inline void TimerHS::setCompOutModeShadowA(CompOutMode val)
{
	REG_(tccrc).comas = val;
}
inline TimerHS::CompOutMode TimerHS::compOutModeShadowB() const
{
	return (CompOutMode) REG_(tccrc).combs;
}
inline void TimerHS::setCompOutModeShadowB(CompOutMode val)
{
	REG_(tccrc).combs = val;
}
inline TimerHS::CompOutMode TimerHS::compOutModeD() const
{
	return (CompOutMode) REG_(tccrc).comd;
}
inline void TimerHS::setCompOutModeD(CompOutMode val)
{
	REG_(tccrc).comd = val;
}
inline void TimerHS::forceOutputCompareD()
{
	REG_(tccrc).focd = true;
}
inline bool TimerHS::isPWMDEnabled() const
{
	return REG_(tccrc).pwmd;
}
inline void TimerHS::enablePWMD()
{
	REG_(tccrc).pwmd = true;
}
inline void TimerHS::disablePWMD()
{
	REG_(tccrc).pwmd = false;
}
inline bool TimerHS::isFaultProtIntEnabled() const
{
	return REG_(tccrd).fpie;
}
inline void TimerHS::enableFaultProtInt()
{
	REG_(tccrd).fpie = true;;
}
inline void TimerHS::disableFaultProtInt()
{
	REG_(tccrd).fpie = false;
}
inline bool TimerHS::isFaultProtModeEnabled() const
{
	return REG_(tccrd).fpen;
}
inline void TimerHS::enableFaultProtMode()
{
	REG_(tccrd).fpen = true;
}
inline void TimerHS::disableFaultProtMode()
{
	REG_(tccrd).fpen = false;
}
inline bool TimerHS::isFaultProtNoiseCancelerOn() const
{
	return REG_(tccrd).fpnc;
}
inline void TimerHS::setFaultProtNoiseCancelerOn()
{
	REG_(tccrd).fpnc = true;
}
inline void TimerHS::setFaultProtNoiseCancelerOff()
{
	REG_(tccrd).fpnc = false;
}
inline TimerHS::EdgeSelect TimerHS::faultProtEdgeSelect() const
{
	return (EdgeSelect) REG_(tccrd).fpes;
}
inline void TimerHS::setFaultProtEdgeSelect(EdgeSelect val)
{
	REG_(tccrd).fpes = val;
}
inline bool TimerHS::isFaultProtAnalogCompEnabled() const
{
	return REG_(tccrd).fpac;
}
inline void TimerHS::enableFaultProtAnalogComp()
{
	REG_(tccrd).fpac = true;
}
inline void TimerHS::disableFaultProtAnalogComp()
{
	REG_(tccrd).fpac = false;
}
inline bool TimerHS::isFaultProtInt() const
{
	return REG_(tccrd).fpf;
}
inline TimerHS::WaveGenMode TimerHS::wavGenMode() const
{
	return (WaveGenMode) REG_(tccrd).wgm;
}
inline void TimerHS::setWavGenMode(WaveGenMode val)
{
	REG_(tccrd).wgm = val;
}
inline bool TimerHS::isRegisterUpdateLocked() const
{
	return REG_(tccre).tlock;
}
inline void TimerHS::lockRegisterUpdate()
{
	REG_(tccre).tlock = true;
}
inline void TimerHS::unlockRegisterUpdate()
{
	REG_(tccre).tlock = false;
}
inline bool TimerHS::isEnhancedModeOn() const
{
	return REG_(tccre).enhc;
}
inline void TimerHS::setEnhancedModeOn()
{
	REG_(tccre).enhc = true;
}
inline void TimerHS::setEnhancedModeOff()
{
	REG_(tccre).enhc = false;
}
inline bool TimerHS::isOutCompOverrideEnableOn(OutCompOverrideEnableBit bit) const
{
	return (REG_(tccre).ocoe & bit);
}
inline void TimerHS::setOutCompOverrideEnableOn(OutCompOverrideEnableBit bit)
{
	REG_(tccre).ocoe |= bit;
}
inline void TimerHS::setOutCompOverrideEnableOff(OutCompOverrideEnableBit bit)
{
	REG_(tccre).ocoe &= ~bit;
}
inline uint8_t TimerHS::counter() const
{
	return REG(tcnt);
}
inline void TimerHS::setCounter(uint8_t val)
{
	REG(tcnt) = val;
}
inline uint8_t TimerHS::outputCompareA() const
{
	return REG(oca);
}
inline void TimerHS::setOutputCompareA(uint8_t val)
{
	REG(oca) = val;
}
inline uint8_t TimerHS::outputCompareB() const
{
	return REG(ocb);
}
inline void TimerHS::setOutputCompareB(uint8_t val)
{
	REG(ocb) = val;
}
inline uint8_t TimerHS::outputCompareC() const
{
	return REG(occ);
}
inline void TimerHS::setOutputCompareC(uint8_t val)
{
	REG(occ) = val;
}
inline uint8_t TimerHS::outputCompareD() const
{
	return REG(ocd);
}
inline void TimerHS::setOutputCompareD(uint8_t val)
{
	REG(ocd) = val;
}
inline unsigned char TimerHS::deadTimeOCx() const
{
	return REG_(dt).dth;
}
inline void TimerHS::setDeadTimeOCx(unsigned char val)
{
	REG_(dt).dtl = val;
}
inline unsigned char TimerHS::deadTimeNOCx() const
{
	return REG_(dt).dtl;
}
inline void TimerHS::setDeadTimeNOCx(unsigned char val)
{
	REG_(dt).dtl = val;
}

#endif /* TIMERHS_H_ */
