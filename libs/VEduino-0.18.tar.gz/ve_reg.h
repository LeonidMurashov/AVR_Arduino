/**
 * reg.h
 *
 *  Created on: 23.01.2012
 *      Author: andrey
 */

#ifndef REG_H_
#define REG_H_

#define REG(_avr_reg)   (*((Reg*) &(_avr_reg)))
#define REGW(_avr_reg)  (*((RegW*) &(_avr_reg)))
#define REG_(_avr_reg)  (_avr_reg.m_reg)
#define TREG_(_avr_reg)  (this->_avr_reg.m_reg)

#define DECLARE_REGT(reg) \
    typedef _AVR_REG_T<AVR_##reg> reg##_REG; \
    typedef reg##_REG* P##reg##_REG; \
    typedef RegT<AVR_##reg> Reg##reg


template<typename _T>
struct _AVR_REG_T
{
    volatile _T m_reg;
};

template<typename _T>
class RegT: public _AVR_REG_T<_T>
{
public:
    RegT& operator =(_T val)
    {
        this->m_reg = val;
        return (*this);
    }
    operator _T()
    {
        return this->m_reg;
    }
    RegT& set(uint8_t bit)
    {
        this->m_reg |= _BV(bit);
        return (*this);
    }
    RegT& reset(uint8_t bit)
    {
        this->m_reg &= ~_BV(bit);
        return (*this);
    }
    bool isSet(_T bit)
    {
        return (this->m_reg & _BV(bit));
    }
    RegT& operator |=(_T val)
    {
        this->m_reg |= val;
        return (*this);
    }
    RegT& operator &=(_T val)
    {
        this->m_reg &= val;
        return (*this);
    }
};

typedef _AVR_REG_T<uint8_t> AVR_REG;
typedef AVR_REG* AVRP_REG;
typedef RegT<uint8_t> Reg;

typedef _AVR_REG_T<uint16_t> AVR_REGW;
typedef AVR_REG* AVRP_REGW;
typedef RegT<uint16_t> RegW;

#endif /* REG_H_ */
