/*
 * pinchangeinterruptflags.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef PINCHANGEINTERRUPTFLAGS_H_
#define PINCHANGEINTERRUPTFLAGS_H_

/**
 *  Pin Change Interrupt Flags class.
 */
class PinChangeFlags : public AVR_PCIFLAGS
{
public:
	bool isInt0() const;
	void clearInt0();

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega325) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
	bool isInt1() const;
	void clearInt1();
	bool isInt2() const;
	void clearInt2();
#endif
};

inline bool PinChangeFlags::isInt0() const
{
	return REG_(pcifr).pcif0;
}
inline void PinChangeFlags::clearInt0()
{
	REG_(pcifr).pcif0 = false;
}

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega325) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
inline bool PinChangeFlags::isInt1() const
{
	return REG_(pcifr).pcif1;
}
inline void PinChangeFlags::clearInt1()
{
	REG_(pcifr).pcif1 = false;
}
inline bool PinChangeFlags::isInt2() const
{
	return REG_(pcifr).pcif2;
}
inline void PinChangeFlags::clearInt2()
{
	REG_(pcifr).pcif2 = false;
}
#endif

#endif /* PINCHANGEINTERRUPTFLAGS_H_ */
