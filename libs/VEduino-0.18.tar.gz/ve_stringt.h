/**
 * string.h
 *
 *  Created on: 08.02.2012
 *      Author: andrey
 */

#ifndef STRING_H_
#define STRING_H_

#include <stdlib.h>
#include <string.h>

template<typename _CharT, typename _IndexT>
class VeStringT
{
protected:
    _CharT *m_pData;
    _IndexT m_length;
protected:
    void realloc(_IndexT _newLen)
    {
        if (_newLen == 0)
        {
            free(m_pData);
            m_pData = 0;
            m_length = 0;
        }
        else if (_newLen != m_length)
        {
            size_t size = _newLen * sizeof(_CharT);
            _CharT *p = (_CharT*) malloc(size + 1);
            if (p == 0)
            	while(1) {}
            memcpy(p, m_pData, size);
            p[size] = 0;
            m_pData = p;
            m_length = _newLen;
        }
    }
public:
    VeStringT() :
        m_pData(0), m_length(0)
    {
    }
    ~VeStringT()
    {
        realloc(0);
    }
    static bool isSpace(const _CharT& _ch)
    {
        return (_ch < 33 || _ch == 127);
    }
    bool isEmpty() const
    {
        return m_length == 0;
    }
    VeStringT& operator +=(const _CharT& _ch)
    {
        realloc(m_length + 1);
        m_pData[m_length - 1] = _ch;
        return (*this);
    }
    bool operator ==(const _CharT* _str) const
    {
        if (m_length == 0)
            return (_str[0] == 0);
        for (_IndexT n = 0; n < m_length; ++n)
        {
            if (_str[n] == 0)
                return false;
            if (_str[n] != m_pData[n])
                return false;
        }
        return true;
    }
    _CharT operator [](_IndexT _n) const
    {
        return m_pData[_n];
    }
};

typedef VeStringT<char, uint8_t> VeString;

#endif /* STRING_H_ */
