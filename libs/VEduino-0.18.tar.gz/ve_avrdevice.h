/*
 * avrdevice.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef AVRDEVICE_H_
#define AVRDEVICE_H_

#define PDEV	((AVRP_DEV) 0x20)
#define DEV	(*PDEV)

#define DEV_GPIOA		OBJ((GPIO*) &(DEV.gpioa))
#define DEV_GPIOB		OBJ((GPIO*) &(DEV.gpiob))
#define DEV_GPIOC		OBJ((GPIO*) &(DEV.gpioc))
#define DEV_GPIOD		OBJ((GPIO*) &(DEV.gpiod))
#define DEV_GPIOE		OBJ((GPIO*) &(DEV.gpioe))
#define DEV_GPIOF		OBJ((GPIO*) &(DEV.gpiof))
#define DEV_GPIOG		OBJ((GPIO*) &(DEV.gpiog))
#define DEV_GPIOH		OBJ((GPIO*) &(DEV.gpioh))
#define DEV_GPIOJ		OBJ((GPIO*) &(DEV.gpioj))
#define DEV_GPIOK		OBJ((GPIO*) &(DEV.gpiok))
#define DEV_GPIOL		OBJ((GPIO*) &(DEV.gpiol))
#define DEV_USART0     OBJ((_Usart*) &(DEV.usart0))
#define DEV_USART1     OBJ((_Usart*) &(DEV.usart1))
#define DEV_USART2     OBJ((_Usart*) &(DEV.usart2))
#define DEV_USART3     OBJ((_Usart*) &(DEV.usart3))
#define DEV_SREG       OBJ((AVRP_SREG) &(DEV.sreg))
#define DEV_TIMER0     OBJ((Timer0*) &(DEV.timer0))

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega325) || \
	defined(VE_ATmega32U4) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
#define DEV_TICTRL0    OBJ((TimerIntCtrl*) &(DEV.timsk0))
#define DEV_TICTRL1    OBJ((TimerIntCtrlW*) &(DEV.timsk1))
#define DEV_TICTRL2    OBJ((TimerIntCtrl*) &(DEV.timsk2))
#define DEV_POWER      OBJ((Power*) &(DEV.power))
#endif

#if defined(VE_ATmega32)
#define DEV_TICTRL0    OBJ((TimerIntCtrl0*) &(DEV.timsk0))
#define DEV_TICTRL2    OBJ((TimerIntCtrl2*) &(DEV.timsk0))
#define DEV_TWICTRL	OBJ((TWIControl*) &(DEV.twcr))
#endif

#define DEV_TIFLAGS0   OBJ((TimerIntFlags*) &(DEV.tifr0))
#define DEV_TIMER1     OBJ((TimerW*) &(DEV.timer1))
#define DEV_TIFLAGS1   OBJ((TimerIntFlagsW*) &(DEV.tifr1))
#define DEV_TIMER2     OBJ((Timer2*) &(DEV.timer2))
#define DEV_TIFLAGS2   OBJ((TimerIntFlags*) &(DEV.tifr2))
#define DEV_TIMER3     OBJ((TimerW*) &(DEV.timer3))
#define DEV_TICTRL3    OBJ((TimerIntCtrlW*) &(DEV.timsk3))
#define DEV_TIFLAGS3   OBJ((TimerIntFlagsW*) &(DEV.tifr3))

#if defined(VE_ATmega2560)
#define DEV_TIMER4     OBJ((TimerW*) &(DEV.timer4))
#define DEV_TICTRL4    OBJ((TimerIntCtrlW*) &(DEV.timsk4))
#define DEV_TIFLAGS4   OBJ((TimerIntFlagsW*) &(DEV.tifr4))
#endif

#if defined(VE_ATmega32U4)
#define DEV_TIMER4     OBJ((TimerHS*) &(DEV.timer4))
#define DEV_TICTRL4    OBJ((TimerIntCtrlHS*) &(DEV.timsk4))
#define DEV_TIFLAGS4   OBJ((TimerIntFlagsHS*) &(DEV.tifr4))
#endif

#define DEV_TIMER5     OBJ((TimerW*) &(DEV.timer5))
#define DEV_TICTRL5    OBJ((TimerIntCtrlW*) &(DEV.timsk5))
#define DEV_TIFLAGS5   OBJ((TimerIntFlagsW*) &(DEV.tifr5))
#define DEV_ADC     	OBJ((ADConv*) &(DEV.amux))
#define DEV_ANAMUX     OBJ((AnalogMux*) &(DEV.amux))
#define DEV_ANACOMP    OBJ((AnalogComp*) &(DEV.anacomp))
#define DEV_ASYNCST	OBJ((AsyncStatus*) &(DEV.asyncst))
#define DEV_EEPROM		OBJ((EEPROM*) &(DEV.eeprom))
#define DEV_SPM		OBJ((StoreProgMem*) &(DEV.spm))
#define DEV_EXTINTCTRL OBJ((ExtIntControl*) &(DEV.extintctrl))
#define DEV_EXTINTFLAGS OBJ((ExtIntFlags*) &(DEV.extintflags))
#define DEV_GTCTRL		OBJ((GeneralTimerControl*) &(DEV.gtccrs))
#define DEV_MCU		OBJ((MCUControl*) &(DEV.mcu))
#define DEV_PCICTRL	OBJ((PinChangeControl*) &(DEV.pcictrl))
#define DEV_PCIFLAGS	OBJ((PinChangeFlags*) &(DEV.pciflags))
#define DEV_PCIMASK0   OBJ((PinChangeMask*) &(DEV.pcimsk0))
#define DEV_PCIMASK1   OBJ((PinChangeMask*) &(DEV.pcimsk1))
#define DEV_PCIMASK2   OBJ((PinChangeMask*) &(DEV.pcimsk2))
#define DEV_PCIMASK3   OBJ((PinChangeMask*) &(DEV.pcimsk3))
#define DEV_SLEEP		OBJ((SleepControl*) &(DEV.sleep))
#define DEV_SPI		OBJ((SPI*) &(DEV.spi))
#define DEV_TWI		OBJ((TWI*) &(DEV.twi))
#define DEV_WATCHDOG	OBJ((Watchdog*) &(DEV.watchdog))
#define DEV_XMEM		OBJ((ExtMemory*) &(DEV.extmem))
#define DEV_PLL		OBJ((PLL*) &(DEV.pll))
#define DEV_CLKSEL		OBJ((ClockSwitch*) &(DEV.clksel))
#define DEV_USBGEN		OBJ((UsbGen*) &(DEV.usbgen))
#define DEV_USBDEV		OBJ((UsbDevice*) &(DEV.usbdev))
#define DEV_USBEP		OBJ((UsbEndpoint*) &(DEV.usbep))

#endif /* AVRDEVICE_H_ */
