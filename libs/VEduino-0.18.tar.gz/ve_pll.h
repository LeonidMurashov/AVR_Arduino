/*
 * pll.h
 *
 *  Created on: 30.11.2012
 *      Author: andrey
 */

#ifndef PLL_H_
#define PLL_H_

#if defined(VE_ATmega32U4)
typedef struct {
	unsigned char reserved[8];
} PLL_reserved;
#define PLL_PARENT		AVR_PLL, private PLL_reserved, public AVR_PLLFREQ
#endif

/**
 *  PLL Control class.
 */
class PLL: public PLL_PARENT
{
public:
	typedef enum {
		DIV1 = 0,
		DIV2
	} Divider;
	typedef enum {
		SystemClock = 0,
		Internal
	} ClkSrc;
	typedef enum {
		Disconnected = 0,
		x1,
		x1_5,
		x2
	} HSTimMult;
	typedef enum {
		Freq_40MHz = 3,
		Freq_48MHz,
		Freq_56MHz,
		Freq_72MHz = 7,
		Freq_80MHz,
		Freq_88MHz,
		Freq_96MHz
	} OutFreq;
public:
	Divider inputPrescaler() const;
	void setInputPrescaler(Divider val);
	bool isEnabled() const;
	void enable();
	void disable();
	bool isLocked() const;
	void setLock();
	void clearLock();
	ClkSrc clockSource() const;
	void setClockSource(ClkSrc val);
	Divider usbPostscaler() const;
	void setUsbPostscaler(Divider val);
	HSTimMult hsTimerPostcaler() const;
	void setHsTimerPostscaler(HSTimMult val);
	OutFreq lockFrequency() const;
	void setLockFrequency(OutFreq val);
};

inline PLL::Divider PLL::inputPrescaler() const
{
	return (Divider) REG_(pllcsr).pindiv;
}
inline void PLL::setInputPrescaler(Divider val)
{
	REG_(pllcsr).pindiv = val;
}
inline bool PLL::isEnabled() const
{
	return REG_(pllcsr).plle;
}
inline void PLL::enable()
{
	REG_(pllcsr).plle = true;
}
inline void PLL::disable()
{
	REG_(pllcsr).plle = false;
}
inline bool PLL::isLocked() const
{
	return REG_(pllcsr).plock;
}
inline PLL::ClkSrc PLL::clockSource() const
{
	return (ClkSrc) REG_(pllfrq).pinmux;
}
inline void PLL::setClockSource(ClkSrc val)
{
	REG_(pllfrq).pinmux = val;
}
inline PLL::Divider PLL::usbPostscaler() const
{
	return (Divider) REG_(pllfrq).pllusb;
}
inline void PLL::setUsbPostscaler(Divider val)
{
	REG_(pllfrq).pllusb = val;
}
inline PLL::HSTimMult PLL::hsTimerPostcaler() const
{
	return (HSTimMult) REG_(pllfrq).plltm;
}
inline void PLL::setHsTimerPostscaler(HSTimMult val)
{
	REG_(pllfrq).plltm = val;
}
inline PLL::OutFreq PLL::lockFrequency() const
{
	return (OutFreq) REG_(pllfrq).pdiv;
}
inline void PLL::setLockFrequency(OutFreq val)
{
	REG_(pllfrq).pdiv = val;
}

#endif /* PLL_H_ */
