/*
 * twi_atmega32.h
 *
 *  Created on: 05.11.2012
 *      Author: andrey
 */

#ifndef TWI_ATMEGA32_H_
#define TWI_ATMEGA32_H_

/**
 *  Two-Wire Interface (TWI) Control class template.
 */
template <typename _TWCR_REG>
class TWIControlT: public _TWCR_REG
{
public:
	inline bool isInt() const
	{
		return this->m_reg.twint;
	}
	inline void clearInt()
	{
		this->m_reg.twint = true;
	}
	inline bool isAckEnabled() const
	{
		return this->m_reg.twea;
	}
	inline void enableAck()
	{
		this->m_reg.twea = true;
	}
	inline void disableAck()
	{
		this->m_reg.twea = false;
	}
	inline void start()
	{
		this->m_reg.twsta = true;
	}
	inline void endStart()
	{
		this->m_reg.twsta = false;
	}
	inline void stop()
	{
		this->m_reg.twsto = true;
	}
	inline bool isWriteCollision() const
	{
		return this->m_reg.twwc;
	}
	inline bool isEnabled() const
	{
		return this->m_reg.twen;
	}
	inline void enable()
	{
		this->m_reg.twen = true;
	}
	inline void disable()
	{
		this->m_reg.twen = false;
	}
	inline bool isIntEnabled() const
	{
		return this->m_reg.twie;
	}
	inline void enableInt()
	{
		this->m_reg.twie = true;
	}
	inline void disableInt()
	{
		this->m_reg.twie = false;
	}
};

typedef TWIControlT<TWCR_REG> TWIControl;

#endif /* TWI_ATMEGA32_H_ */
