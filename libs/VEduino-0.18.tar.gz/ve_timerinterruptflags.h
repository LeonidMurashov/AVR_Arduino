/*
 * timerinterruptflags.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef TIMERINTERRUPTFLAGS_H_
#define TIMERINTERRUPTFLAGS_H_

/**
 *  Timer/Counter Interrupt Flags class.
 */
template <typename _TIFR_REG>
class TimerIntFlagsT: public _TIFR_REG
{
public:
	bool isOverflow() const {
		return this->m_reg.tov;
	}
	void clearOverflow() {
		this->m_reg.tov = false;
	}
	bool isInputCapture() const {
		return this->m_reg.icf;
	}
	void clearInputCapture() {
		this->m_reg.icf = false;
	}
	bool isOutputCompareMatchA() const {
		return this->m_reg.ocfa;
	}
	void clearOutputCompareMatchA() {
		this->m_reg.ocfa = false;
	}
	bool isOutputCompareMatchB() const {
		return this->m_reg.ocfb;
	}
	void clearOutputCompareMatchB() {
		this->m_reg.ocfb = false;
	}
#if defined(VE_ATmega2560) || \
	defined(VE_ATmega32U4)
	bool isOutputCompareMatchC() const {
		return this->m_reg.ocfc;
	}
	void clearOutputCompareMatchC() {
		this->m_reg.ocfc = false;
	}
#endif
};

typedef TimerIntFlagsT<TIFR_REG> TimerIntFlags;
#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega325) ||\
	defined(VE_ATmega32U4)
typedef TimerIntFlagsT<TIFRW_REG> TimerIntFlagsW;
#endif

#endif /* TIMERINTERRUPTFLAGS_H_ */
