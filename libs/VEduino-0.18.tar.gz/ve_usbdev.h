/*
 * usbdev.h
 *
 *  Created on: 09.12.2012
 *      Author: andrey
 */

#ifndef USBDEV_H_
#define USBDEV_H_

/**
 *  USB Device General class.
 */
class UsbDevice : public AVR_USBDEV
{
	typedef enum {
		FullSpeed  = 0,
		LowSpeed   = 1
	} Mode;
public:
	bool isResetCPUEnabled() const;
	void enableResetCPU();
	void disableResetCPU();
	Mode mode() const;
	void setMode(Mode val);
	void remoteWakeUp();
	bool isSentRemoteWakepUp() const;
	bool isDetached() const;
	void detach();
	void connect();
	bool upstreamResumeInt() const;
	void clearUpstreamResumeInt();
	bool endOfResumeInt() const;
	void clearEndOfResumeInt();
	bool wakeupCPUInt() const;
	void clearWakeupCPUInt();
	bool endOfResetInt() const;
	void clearEndOfResetInt();
	bool startOfFrameInt() const;
	bool suspendInt() const;
	void clearSuspendInt();
	bool isUpstreamResumeIntEnabled() const;
	void enableUpstreamResumeInt();
	void disableUpstreamResumeInt();
	bool isEndOfResumeIntEnabled() const;
	void enableEndOfResumeInt();
	void disableEndOfResumeInt();
	bool isWakeupCPUIntEnabled() const;
	void enableWakeupCPUInt();
	void disableWakeupCPUInt();
	bool isEndOfResetIntEnabled() const;
	void enableEndOfResetInt();
	void disableEndOfResetInt();
	bool isStartOfFrameIntEnabled() const;
	void enableStartOfFrameInt();
	void disableStartOfFrameInt();
	bool isSuspendIntEnabled() const;
	void enableSuspendInt();
	void disableSuspendInt();
	bool isAddressEnabled() const;
	void enableAddress();
	unsigned char address() const;
	void setAddress(unsigned char val);
	unsigned int frameNumber() const;
	bool isFrameNumberCRCError() const;
};

inline bool UsbDevice::isResetCPUEnabled() const
{
	return REG_(udcon).rstcpu;
}
inline void UsbDevice::enableResetCPU()
{
	REG_(udcon).rstcpu = true;
}
inline void UsbDevice::disableResetCPU()
{
	REG_(udcon).rstcpu = false;
}
inline UsbDevice::Mode UsbDevice::mode() const
{
	return (Mode) REG_(udcon).lsm;
}
inline void UsbDevice::setMode(Mode val)
{
	REG_(udcon).lsm = val;
}
inline void UsbDevice::remoteWakeUp()
{
	REG_(udcon).rmwkup = true;
}
inline bool UsbDevice::isSentRemoteWakepUp() const
{
	return ! REG_(udcon).rmwkup;
}
inline bool UsbDevice::isDetached() const
{
	return REG_(udcon).detach;
}
inline void UsbDevice::detach()
{
	REG_(udcon).detach = true;
}
inline void UsbDevice::connect()
{
	REG_(udcon).detach = false;
}
inline bool UsbDevice::upstreamResumeInt() const
{
	return REG_(udint).uprsmi;
}
inline void UsbDevice::clearUpstreamResumeInt()
{
	REG_(udint).uprsmi = false;
}
inline bool UsbDevice::endOfResumeInt() const
{
	return REG_(udint).eorsmi;
}
inline void UsbDevice::clearEndOfResumeInt()
{
	REG_(udint).eorsmi = false;
}
inline bool UsbDevice::wakeupCPUInt() const
{
	return REG_(udint).wakeupi;
}
inline void UsbDevice::clearWakeupCPUInt()
{
	REG_(udint).wakeupi = false;
}
inline bool UsbDevice::endOfResetInt() const
{
	return REG_(udint).eorsti;
}
inline void UsbDevice::clearEndOfResetInt()
{
	REG_(udint).eorsti = false;
}
inline bool UsbDevice::startOfFrameInt() const
{
	return REG_(udint).sofi;
}
inline bool UsbDevice::suspendInt() const
{
	return REG_(udint).suspi;
}
inline void UsbDevice::clearSuspendInt()
{
	REG_(udint).suspi = false;
}
inline bool UsbDevice::isUpstreamResumeIntEnabled() const
{
	return REG_(udien).uprsme;
}
inline void UsbDevice::enableUpstreamResumeInt()
{
	REG_(udien).uprsme = true;
}
inline void UsbDevice::disableUpstreamResumeInt()
{
	REG_(udien).uprsme = false;
}
inline bool UsbDevice::isEndOfResumeIntEnabled() const
{
	return REG_(udien).eorsme;
}
inline void UsbDevice::enableEndOfResumeInt()
{
	REG_(udien).eorsme = true;
}
inline void UsbDevice::disableEndOfResumeInt()
{
	REG_(udien).eorsme = false;
}
inline bool UsbDevice::isWakeupCPUIntEnabled() const
{
	return REG_(udien).wakeupe;
}
inline void UsbDevice::enableWakeupCPUInt()
{
	REG_(udien).wakeupe = true;
}
inline void UsbDevice::disableWakeupCPUInt()
{
	REG_(udien).wakeupe = false;
}
inline bool UsbDevice::isEndOfResetIntEnabled() const
{
	return REG_(udien).eorste;
}
inline void UsbDevice::enableEndOfResetInt()
{
	REG_(udien).eorste = true;
}
inline void UsbDevice::disableEndOfResetInt()
{
	REG_(udien).eorste = false;
}
inline bool UsbDevice::isStartOfFrameIntEnabled() const
{
	return REG_(udien).sofe;
}
inline void UsbDevice::enableStartOfFrameInt()
{
	REG_(udien).sofe = true;
}
inline void UsbDevice::disableStartOfFrameInt()
{
	REG_(udien).sofe = false;
}
inline bool UsbDevice::isSuspendIntEnabled() const
{
	return REG_(udien).suspe;
}
inline void UsbDevice::enableSuspendInt()
{
	REG_(udien).suspe = true;
}
inline void UsbDevice::disableSuspendInt()
{
	REG_(udien).suspe = false;
}
inline bool UsbDevice::isAddressEnabled() const
{
	return REG_(udaddr).adden;
}
inline void UsbDevice::enableAddress()
{
	REG_(udaddr).adden = true;
}
inline unsigned char UsbDevice::address() const
{
	return REG_(udaddr).uadd;
}
inline void UsbDevice::setAddress(unsigned char val)
{
	REG_(udaddr).uadd = val;
}
inline unsigned int UsbDevice::frameNumber() const
{
	return REGW(udfnum);
}
inline bool UsbDevice::isFrameNumberCRCError() const
{
	return REG_(udmfn).fncerr;
}

#endif /* USBDEV_H_ */
