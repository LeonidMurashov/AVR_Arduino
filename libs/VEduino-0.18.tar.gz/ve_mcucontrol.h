/*
 * mcucontrol.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef MCUCONTROL_H_
#define MCUCONTROL_H_

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega325) || \
	defined(VE_ATmega32U4) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
#define MCUCONTROL_PARENT AVR_MCU
#endif

#if defined(VE_ATmega32)
typedef struct {
	unsigned char reserved[3];
} __MCUP0;
typedef struct {
	unsigned char reserved[4];
} __MCUP1;
#define MCUCONTROL_PARENT AVR_SFIORS, private __MCUP0, public AVR_MCU, private __MCUP1, public AVR_EXTINTFLAGS
#endif

/**
 *  MCU Control class.
 */
class MCUControl : public MCUCONTROL_PARENT
{
public:
	bool isIntVectorsAtProgMem() const;
	void setIntVectorsToProgMem();
	void setIntVectorsToBootLoader();
	bool isPullUpsDisabled() const;
	void enablePullUps();
	void disablePullUps();
	bool isWatchdogResetOccurs() const;
	bool isBrownOutResetOccurs() const;
	bool isExternalResetOccurs() const;
	bool isPowerOnResetOccurs() const;
	void clearWatchdogReset();
#if defined(VE_ATmega328P)
	void bodOffSleep();
#endif
#if defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
	bool isJtagDisabled() const;
	void enableJtag();
	void disableJtag();
#endif
};

inline bool MCUControl::isWatchdogResetOccurs() const
{
	return REG_(mcusr).wdrf;
}
inline bool MCUControl::isBrownOutResetOccurs() const
{
	return REG_(mcusr).borf;
}
inline bool MCUControl::isExternalResetOccurs() const
{
	return REG_(mcusr).extrf;
}
inline bool MCUControl::isPowerOnResetOccurs() const
{
	return REG_(mcusr).porf;
}
inline void MCUControl::clearWatchdogReset()
{
	REG_(mcusr).wdrf = false;
}

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega325)
inline bool MCUControl::isIntVectorsAtProgMem() const
{
	return (REG_(mcucr).iv & 2);
}
inline void MCUControl::setIntVectorsToProgMem()
{
	register uint8_t sreg = SREG;
	disableInterrupts();
	REG_(mcucr).iv = 1;
	REG_(mcucr).iv = 0;
	SREG = sreg;
}
inline void MCUControl::setIntVectorsToBootLoader()
{
	register uint8_t sreg = SREG;
	disableInterrupts();
	REG_(mcucr).iv = 1;
	REG_(mcucr).iv = 2;
	SREG = sreg;
}
inline bool MCUControl::isPullUpsDisabled() const
{
	return REG_(mcucr).pud;
}
inline void MCUControl::enablePullUps()
{
	REG_(mcucr).pud = false;
}
inline void MCUControl::disablePullUps()
{
	REG_(mcucr).pud = true;
}
#endif

#if defined(VE_ATmega32)
inline bool MCUControl::isIntVectorsAtProgMem() const
{
	return !REG_(gicr).ivsel;
}
inline void MCUControl::setIntVectorsToProgMem()
{
	register uint8_t sreg = SREG;
	disableInterrupts();
	REG_(gicr).ivce = 1;
	REG_(gicr).ivsel = 0;
	SREG = sreg;
}
inline void MCUControl::setIntVectorsToBootLoader()
{
	register uint8_t sreg = SREG;
	disableInterrupts();
	REG_(gicr).ivce = 1;
	REG_(gicr).ivsel = 2;
	SREG = sreg;
}
inline bool MCUControl::isPullUpsDisabled() const
{
	return REG_(sfior).pud;
}
inline void MCUControl::enablePullUps()
{
	REG_(sfior).pud = false;
}
inline void MCUControl::disablePullUps()
{
	REG_(sfior).pud = true;
}
#endif

#if defined(VE_ATmega328P)
inline void MCUControl::bodOffSleep()
{
	register uint8_t sreg = SREG;
	disableInterrupts();
	REG_(mcucr).bods = 3;
	REG_(mcucr).bods = 2;
	SREG = sreg;
	__asm__ __volatile__ ("sleep");
}
#endif

#if defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
inline bool MCUControl::isJtagDisabled() const
{
	return REG_(mcucr).jtd;
}
inline void MCUControl::enableJtag()
{
	REG_(mcucr).jtd = false;
	REG_(mcucr).jtd = false;
}
inline void MCUControl::disableJtag()
{
	REG_(mcucr).jtd = true;
	REG_(mcucr).jtd = true;
}
#endif


#endif /* MCUCONTROL_H_ */
