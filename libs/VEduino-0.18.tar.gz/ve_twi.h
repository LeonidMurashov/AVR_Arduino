/*
 * twi.h
 *
 *  Created on: 25.10.2012
 *      Author: andrey
 */

#ifndef TWI_H_
#define TWI_H_

/**
 *  Two-Wire Serial Interface (TWI) class.
 */
class TWI: public AVR_TWI
{
public:
	typedef enum {
		BUS_ERROR = 0,
		START = 1,
		REP_START = 2,
		MT_SLA_ACK = 3,
		MT_SLA_NACK = 4,
		MT_DATA_ACK = 5,
		MT_DATA_NACK = 6,
		M_ARB_LOST = 7,
		MR_SLA_ACK = 8,
		MR_SLA_NACK = 9,
		MR_DATA_ACK = 10,
		MR_DATA_NACK = 11,
		SR_SLA_ACK = 12,
		SR_ARB_LOST_SLA_ACK = 13,
		SR_GCALL_SLA_ACK = 14,
		SR_ARB_LOST_GCALL_SLA_ACK = 15,
		SR_DATA_ACK = 16,
		SR_DATA_NACK = 17,
		SR_GCALL_DATA_ACK = 18,
		SR_GCALL_DATA_NACK = 19,
		SR_STOP = 20,
		ST_SLA_ACK = 21,
		ST_ARB_LOST_SLA_ACK = 22,
		ST_DATA_ACK = 23,
		ST_DATA_NACK = 24,
		ST_LAST_DATA = 25,
		NO_INFO = 31
	} Status;
	typedef enum {
		DIV_1 = 0,
		DIV_4,
		DIV_16,
		DIV_64
	} Prescaler;
public:
	uint8_t bitRate() const;
	void setBitRate(uint8_t val);
	bool isInt() const;
	void clearInt();
	bool isAckEnabled() const;
	void enableAck();
	void disableAck();
	void start();
	void endStart();
	void stop();
	bool isWriteCollision() const;
	bool isEnabled() const;
	void enable();
	void disable();
	bool isIntEnabled() const;
	void enableInt();
	void disableInt();
	Status status() const;
	Prescaler prescaler() const;
	void setPrescaler(Prescaler val);
	bool isGeneralCallEnabled() const;
	void enableGeneralCall();
	void disableGeneralCall();
	uint8_t address() const;
	void setAddress(uint8_t val);

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega325)
	uint8_t addressMask() const;
	void setAddressMask(uint8_t val);
#endif
};

#if defined(VE_ATmega32)
#include "ve_twi_atmega32.h"
#endif

inline uint8_t TWI::bitRate() const
{
	return REG_(twbr);
}
inline void TWI::setBitRate(uint8_t val)
{
	REG_(twbr) = val;
}
inline TWI::Status TWI::status() const
{
	return (Status) REG_(twsr).tws;
}
inline TWI::Prescaler TWI::prescaler() const
{
	return (Prescaler) REG_(twsr).twps;
}
inline void TWI::setPrescaler(Prescaler val)
{
	REG_(twsr).twps = val;
}
inline bool TWI::isGeneralCallEnabled() const
{
	return REG_(twar).twgce;
}
inline void TWI::enableGeneralCall()
{
	REG_(twar).twgce = true;
}
inline void TWI::disableGeneralCall()
{
	REG_(twar).twgce = false;
}
inline uint8_t TWI::address() const
{
	return REG_(twar).twa;
}
inline void TWI::setAddress(uint8_t val)
{
	REG_(twar).twa = val;
}

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega325)
inline bool TWI::isInt() const
{
	return REG_(twcr).twint;
}
inline void TWI::clearInt()
{
	REG_(twcr).twint = true;
}
inline bool TWI::isAckEnabled() const
{
	return REG_(twcr).twea;
}
inline void TWI::enableAck()
{
	REG_(twcr).twea = true;
}
inline void TWI::disableAck()
{
	REG_(twcr).twea = false;
}
inline void TWI::start()
{
	REG_(twcr).twsta = true;
}
inline void TWI::endStart()
{
	REG_(twcr).twsta = false;
}
inline void TWI::stop()
{
	REG_(twcr).twsto = true;
}
inline bool TWI::isWriteCollision() const
{
	return REG_(twcr).twwc;
}
inline bool TWI::isEnabled() const
{
	return REG_(twcr).twen;
}
inline void TWI::enable()
{
	REG_(twcr).twen = true;
}
inline void TWI::disable()
{
	REG_(twcr).twen = false;
}
inline bool TWI::isIntEnabled() const
{
	return REG_(twcr).twie;
}
inline void TWI::enableInt()
{
	REG_(twcr).twie = true;
}
inline void TWI::disableInt()
{
	REG_(twcr).twie = false;
}
inline uint8_t TWI::addressMask() const
{
	return REG_(twamr).twam;
}
inline void TWI::setAddressMask(uint8_t val)
{
	REG_(twamr).twam = val;
}
#endif

#if defined(VE_ATmega32)
inline bool TWI::isInt() const
{
	return DEV_TWICTRL.isInt();
}
inline void TWI::clearInt()
{
	DEV_TWICTRL.clearInt();
}
inline bool TWI::isAckEnabled() const
{
	return DEV_TWICTRL.isAckEnabled();
}
inline void TWI::enableAck()
{
	DEV_TWICTRL.enableAck();
}
inline void TWI::disableAck()
{
	DEV_TWICTRL.disableAck();
}
inline void TWI::start()
{
	DEV_TWICTRL.start();
}
inline void TWI::endStart()
{
	DEV_TWICTRL.endStart();
}
inline void TWI::stop()
{
	DEV_TWICTRL.stop();
}
inline bool TWI::isWriteCollision() const
{
	return DEV_TWICTRL.isWriteCollision();
}
inline bool TWI::isEnabled() const
{
	return DEV_TWICTRL.isEnabled();
}
inline void TWI::enable()
{
	DEV_TWICTRL.enable();
}
inline void TWI::disable()
{
	DEV_TWICTRL.disable();
}
inline bool TWI::isIntEnabled() const
{
	return DEV_TWICTRL.isIntEnabled();
}
inline void TWI::enableInt()
{
	DEV_TWICTRL.enableInt();
}
inline void TWI::disableInt()
{
	DEV_TWICTRL.disableInt();
}
#endif

#endif /* TWI_H_ */
