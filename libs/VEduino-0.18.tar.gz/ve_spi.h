/*
 * spi.h
 *
 *  Created on: 24.10.2012
 *      Author: andrey
 */

#ifndef SPI_H_
#define SPI_H_

/**
 *  Serial Peripheral Interface (SPI) class.
 */
class SPI: public AVR_SPI
{
public:
	typedef enum {
		MSB_FIRST = 0,
		LSB_FIRST
	} DataOrder;
	typedef enum {
		SCK_LOW = 0,
		SCK_HIGH
	} CPol;
	typedef enum {
		LEAD_SAMPLE = 0,
		LEAD_SETUP
	} CPha;
	typedef enum {
		DIV_4 = 0,
		DIV_16,
		DIV_64,
		DIV_128
	} Rate;
public:
	bool isIntEnabled() const;
	void enableInt();
	void disableInt();
	bool isEnabled() const;
	void enable();
	void disable();
	DataOrder dataOrder() const;
	void setDataOrder(DataOrder val);
	bool isMaster() const;
	void setMaster(bool ssOutput = true);
	void setSlave();
	CPol clockPolarity() const;
	void setClockPolarity(CPol val);
	CPha clockPhase() const;
	void setClockPhase(CPha val);
	Rate rate() const;
	void setRate(Rate val);
	bool isInt() const;
	void clearInt();
	bool isWriteCollision() const;
	void clearWriteCollision();
	bool isDoubleSpeed() const;
	void setDoubleSpeed();
	void setSingleSpeed();
	uint8_t read();
	uint8_t write(uint8_t data);
};

inline bool SPI::isIntEnabled() const
{
	return REG_(spcr).spie;
}
inline void SPI::enableInt()
{
	REG_(spcr).spie = true;
}
inline void SPI::disableInt()
{
	REG_(spcr).spie = false;
}
inline bool SPI::isEnabled() const
{
	return REG_(spcr).spe;
}
inline void SPI::enable()
{
	REG_(spcr).spe = true;
}
inline void SPI::disable()
{
	REG_(spcr).spe = false;
}
inline SPI::DataOrder SPI::dataOrder() const
{
	return (DataOrder) REG_(spcr).dord;
}
inline void SPI::setDataOrder(DataOrder val)
{
	REG_(spcr).dord = val;
}
inline bool SPI::isMaster() const
{
	return REG_(spcr).mstr;
}
inline void SPI::setMaster(bool ssOutput)
{
	setModeInput(DEV_SPI_MISO);
	setModeOutput(DEV_SPI_SCK);
	setModeOutput(DEV_SPI_MOSI);
	if (ssOutput)
		setModeOutput(DEV_SPI_SS);
	else
		setModeInput(DEV_SPI_SS);
	REG_(spcr).mstr = true;
}
inline void SPI::setSlave()
{
	setModeOutput(DEV_SPI_MISO);
	setModeInput(DEV_SPI_SCK);
	setModeInput(DEV_SPI_MOSI);
	setModeInput(DEV_SPI_SS);
	REG_(spcr).mstr = false;
}
inline SPI::CPol SPI::clockPolarity() const
{
	return (CPol) REG_(spcr).cpol;
}
inline void SPI::setClockPolarity(CPol val)
{
	REG_(spcr).cpol = val;
}
inline SPI::CPha SPI::clockPhase() const
{
	return (CPha) REG_(spcr).cpha;
}
inline void SPI::setClockPhase(CPha val)
{
	REG_(spcr).cpha = val;
}
inline SPI::Rate SPI::rate() const
{
	return (Rate) REG_(spcr).spr;
}
inline void SPI::setRate(Rate val)
{
	REG_(spcr).spr = val;
}
inline bool SPI::isInt() const
{
	return REG_(spsr).spif;
}
inline void SPI::clearInt()
{
	register uint8_t dummy = REG_(spsr).spif;
	dummy = REG_(spdr);
	UNUSED(dummy);
}
inline bool SPI::isWriteCollision() const
{
	return REG_(spsr).wcol;
}
inline void SPI::clearWriteCollision()
{
	register uint8_t dummy = REG_(spsr).wcol;
	dummy = REG_(spdr);
	UNUSED(dummy);
}
inline bool SPI::isDoubleSpeed() const
{
	return REG_(spsr).spi2x;
}
inline void SPI::setDoubleSpeed()
{
	REG_(spsr).spi2x = true;
}
inline void SPI::setSingleSpeed()
{
	REG_(spsr).spi2x = false;
}
inline uint8_t SPI::read()
{
	while(! isInt());
	return REG_(spdr);
}
inline uint8_t SPI::write(uint8_t data)
{
	REG_(spdr) = data;
	return read();
}

#endif /* SPI_H_ */
