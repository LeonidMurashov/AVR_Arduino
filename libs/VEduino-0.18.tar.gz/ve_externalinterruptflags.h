/*
 * externalinterruptflags.h
 *
 *  Created on: 30.10.2012
 *      Author: andrey
 */

#ifndef EXTERNALINTERRUPTFLAGS_H_
#define EXTERNALINTERRUPTFLAGS_H_

#define EIF_DECLARE(num) \
	inline bool isInterrupt##num () const { \
		return REG_(eifr).intf##num; \
	} \
	inline void clearInterrupt##num () { \
		REG_(eifr).intf##num = false; \
	} \
	inline bool isInterrupt##num##Enabled() const { \
		return REG_(eimsk).int##num; \
	} \
	inline void enableInterrupt##num() { \
		REG_(eimsk).int##num = true; \
	} \
	inline void disableInterrupt##num() { \
		REG_(eimsk).int##num = false; \
	}

/**
 *  External Interrupt Flags class.
 */
class ExtIntFlags : public AVR_EXTINTFLAGS
{
public:
	EIF_DECLARE(0)
#if defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P) || \
	defined(VE_ATmega32U4) || \
	defined(VE_ATmega328P)
	EIF_DECLARE(1)
#endif
#if defined(VE_ATmega2560) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P) || \
	defined(VE_ATmega32U4)
	EIF_DECLARE(2)
#endif
#if defined(VE_ATmega2560) || \
	defined(VE_ATmega32U4)
	EIF_DECLARE(3)
#endif
#if defined(VE_ATmega2560)
	EIF_DECLARE(4)
	EIF_DECLARE(5)
	EIF_DECLARE(6)
	EIF_DECLARE(7)
#endif
};

#endif /* EXTERNALINTERRUPTFLAGS_H_ */
