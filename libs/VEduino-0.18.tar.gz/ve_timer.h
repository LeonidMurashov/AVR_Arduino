/**
 * timer.h
 *
 *  Created on: 09.02.2012
 *      Author: andrey
 */

#ifndef TIMER_H_
#define TIMER_H_

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega325) || \
	defined(VE_ATmega32U4) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
#define TIMERT_TEMPLATE template<typename _avr_timerT, typename _PrescalerT>
#define TIMERT_PARENT _avr_timerT
#endif

#if defined(VE_ATmega32)
typedef struct {
	unsigned char reserved[8];
} __TimerTP;
typedef struct {
	AVR_REG ocra;
} __TimerTOCRA0;
typedef struct {
} __TimerTOCRA2;
#define TIMERT_TEMPLATE template<typename _avr_timerT, typename _avr_ocraT, typename _PrescalerT>
#define TIMERT_PARENT _avr_timerT, private __TimerTP, public _avr_ocraT
#endif

/**
 *  8-bit Timer/Counter class.
 */
TIMERT_TEMPLATE
class TimerT: public TIMERT_PARENT
{
public:
    typedef enum
    {
        Disconnected = 0,
        Toggle,
        Clear,
        Set
    } CompOutMode;
    typedef enum
    {
        Normal = 0,
        PhaseCorrect,
        CTC,
        FastPWM,
        PhaseCorrect_OCRA = 5,
        FastPWM_OCRA = 7
    } WaveGenMode;
    typedef typename _PrescalerT::ClkSelect _ClkSelectT;
public:
    uint16_t prescaler() const
    {
        return _PrescalerT::prescaler(clockSelect());
    }
    uint8_t counter() const
    {
        return TREG_(tcnt);
    }
    void setCounter(uint8_t val)
    {
        TREG_(tcnt) = val;
    }
    uint8_t outputCompareA() const
    {
        return TREG_(ocra);
    }
    void setOutputCompareA(uint8_t val)
    {
        TREG_(ocra) = val;
    }
    CompOutMode compOutModeA() const
    {
        return (CompOutMode) TREG_(tccra).coma;
    }
    void setCompOutModeA(CompOutMode val)
    {
        TREG_(tccra).coma = val;
    }

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega32U4) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
    uint8_t outputCompareB() const
    {
        return TREG_(ocrb);
    }
    void setOutputCompareB(uint8_t val)
    {
        TREG_(ocrb) = val;
    }
    CompOutMode compOutModeB() const
    {
        return (CompOutMode) TREG_(tccra).comb;
    }
    void setCompOutModeB(CompOutMode val)
    {
        TREG_(tccra).comb = val;
    }
#endif

    WaveGenMode wavGenMode() const
    {
#if defined(VE_ATmega328P) || \
    defined(VE_ATmega2560) || \
 	defined(VE_ATmega32U4) || \
 	defined(VE_ATmega644PA) || \
 	defined(VE_ATmega1284P)
        return (WaveGenMode) ((TREG_(tccrb).wgm2 << 2) | TREG_(tccra).wgm);
#else
        return (WaveGenMode) ((TREG_(tccra).wgm1 << 1) | TREG_(tccra).wgm0);
#endif
    }
    void setWaveGenMode(WaveGenMode val)
    {
#if defined(VE_ATmega328P) || \
     defined(VE_ATmega2560) || \
     defined(VE_ATmega32U4) || \
     defined(VE_ATmega644PA) || \
     defined(VE_ATmega1284P)
        TREG_(tccra).wgm = val & 3;
        TREG_(tccrb).wgm2 = (val & 4) ? 1 : 0;
#else
        TREG_(tccra).wgm0 = val & 1;
        TREG_(tccra).wgm1 = val >> 1;
#endif
    }
    _ClkSelectT clockSelect() const
    {
#if defined(VE_ATmega328P) || \
    defined(VE_ATmega2560) || \
    defined(VE_ATmega32U4) || \
    defined(VE_ATmega644PA) || \
    defined(VE_ATmega1284P)
        return (_ClkSelectT) TREG_(tccrb).cs;
#else
        return TREG_(tccra).cs;
#endif
    }
    void setClockSelect(_ClkSelectT val)
    {
#if defined(VE_ATmega328P) || \
     defined(VE_ATmega2560) || \
     defined(VE_ATmega32U4) || \
     defined(VE_ATmega644PA) || \
     defined(VE_ATmega1284P)
        TREG_(tccrb).cs = val;
#else
        TREG_(tccra).cs = val;
#endif
    }
    void forceOutputCompareA()
    {
        TREG_(tccrb).foca = true;
    }
};

#if defined(VE_ATmega328P) || \
	defined(VE_ATmega2560) || \
	defined(VE_ATmega325) || \
	defined(VE_ATmega32U4) || \
	defined(VE_ATmega644PA) || \
	defined(VE_ATmega1284P)
typedef TimerT<AVR_TIMER, Prescaler0> Timer0;
typedef TimerT<AVR_TIMER, Prescaler2> Timer2;
#endif

#if defined(VE_ATmega32)
typedef TimerT<AVR_TIMER0, __TimerTOCRA0, Prescaler0> Timer0;
typedef TimerT<AVR_TIMER2, __TimerTOCRA2, Prescaler2> Timer2;
#endif

#endif /* TIMER_H_ */
