/*
 * usbgen.h
 *
 *  Created on: 09.12.2012
 *      Author: andrey
 */

#ifndef USBGEN_H_
#define USBGEN_H_

/**
 *  USB General class.
 */
class UsbGen : public AVR_USBGEN
{
public:
	bool isPadRegEnabled() const;
	void enablePadReg();
	void disablePadReg();
	bool isEnabled() const;
	void enable();
	void disable();
	bool isClockDisabled() const;
	void disableClock();
	void enableClock();
	bool isPadEnabled() const;
	void enablePad();
	void disablePad();
	bool isTransIntEnabled() const;
	void enableTransInt();
	void disableTransInt();
	bool idStatus() const;
	bool vbus() const;
	bool isTransitionInt() const;
	void clearTransitionInt();
};

inline bool UsbGen::isPadRegEnabled() const
{
	return REG_(uhwcon).uvrege;
}
inline void UsbGen::enablePadReg()
{
	REG_(uhwcon).uvrege = true;
}
inline void UsbGen::disablePadReg()
{
	REG_(uhwcon).uvrege = false;
}
inline bool UsbGen::isEnabled() const
{
	return REG_(usbcon).usbe;
}
inline void UsbGen::enable()
{
	REG_(usbcon).usbe = true;
}
inline void UsbGen::disable()
{
	REG_(usbcon).usbe = false;
}
inline bool UsbGen::isClockDisabled() const
{
	return REG_(usbcon).frzclk;
}
inline void UsbGen::disableClock()
{
	REG_(usbcon).frzclk = true;
}
inline void UsbGen::enableClock()
{
	REG_(usbcon).frzclk = false;
}
inline bool UsbGen::isPadEnabled() const
{
	return REG_(usbcon).otgpade;
}
inline void UsbGen::enablePad()
{
	REG_(usbcon).otgpade = true;
}
inline void UsbGen::disablePad()
{
	REG_(usbcon).otgpade = false;
}
inline bool UsbGen::isTransIntEnabled() const
{
	return REG_(usbcon).vbuste;
}
inline void UsbGen::enableTransInt()
{
	REG_(usbcon).vbuste = true;
}
inline void UsbGen::disableTransInt()
{
	REG_(usbcon).vbuste = false;
}
inline bool UsbGen::idStatus() const
{
	return REG_(usbsta).id;
}
inline bool UsbGen::vbus() const
{
	return REG_(usbsta).vbus;
}
inline bool UsbGen::isTransitionInt() const
{
	return REG_(usbint).vbusti;
}
inline void UsbGen::clearTransitionInt()
{
	REG_(usbint).vbusti = false;
}


#endif /* USBGEN_H_ */
