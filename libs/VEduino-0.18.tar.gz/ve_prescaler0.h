/**
 * prescaler0.h
 *
 *  Created on: 10.02.2012
 *      Author: andrey
 */

#ifndef PRESCALER0_H_
#define PRESCALER0_H_

/**
 *  8-bit Timer/Counter 0 Prescaler class.
 */
class Prescaler0
{
public:
    typedef enum
    {
        Stopped = 0,
        Prescaler_1 = 1,
        Prescaler_8 = 2,
        Prescaler_64 = 3,
        Prescaler_256 = 4,
        Prescaler_1024 = 5,
        ExtClkFalling = 6,
        ExtClkRising = 7
    } ClkSelect;
public:
    static uint16_t prescaler(ClkSelect _cksel);
};

inline uint16_t Prescaler0::prescaler(ClkSelect _cksel)
{
    switch (_cksel)
    {
    case Prescaler_8:
        return 8;
    case Prescaler_64:
        return 64;
    case Prescaler_256:
        return 256;
    case Prescaler_1024:
        return 1024;
    default:
        return 1;
    }
}

#endif /* PRESCALER0_H_ */
